"""Exact retained synthetic template metadata, no execution authority or payload I/O.

Only build_from_safe_receipts opens files: a fixed nonsecret receipt allowlist.
All six ciphertexts and the credential are lstat-only during source preparation.
"""
import hashlib
import json
import os
import re
import stat
from pathlib import Path

ASSIGNMENT = 'ASTRA-CHILD-F06-TEMPLATES-OFFICE-SOURCE-PREPARE-20261112#1'
NATIVE_ASSIGNMENT = 'ASTRA-CHILD-F06-ODF-TEMPLATE-NATIVE-PATHS-20261112#1'
NATIVE_ROOT = Path('/home/jericho/.cache/FRW-ASTRA-V3-F06-ODF-TEMPLATE-NATIVE-PATHS-20261112')
RESULT_PATH = NATIVE_ROOT/'RESULT.json'
RESULT_SHA = 'fc5d4a4de888b9c0aeb85deae92f376fced948edc3e1213bfc3f44c1975f18fa'
ACCEPT_PATH = Path('/home/jericho/.cache/FRW-ASTRA-V3-POSTPOWER-RECOVERY-20261111/F06-ODF-TEMPLATE-NATIVE-ROOT-ACCEPTANCE-20261112.json')
ACCEPT_SHA = '5fdd4052242c651e7dec4029f28d43f6de096721cee5b6db56302680cb143362'
SPEC_PATH = NATIVE_ROOT/'spec_fixture.py'
SPEC_SHA = 'bcd07bc02816508ea05793b952c2a47962bfdbaf410ceb616bd246dd92828139'
SCHEMA = 'friday.f06.retained-template-source-output-oracle.v1'
SEMANTIC = 'SYNTHETIC_TEMPLATE_BEFORE_AFTER'
FORMATS = ('ott','ots','otp')
ROLES = ('source','output')
IDS = tuple('template-'+fmt+'-'+role for fmt in FORMATS for role in ROLES)
IDENTITY_FIELDS = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
MIMES = dict(zip(FORMATS,('application/vnd.oasis.opendocument.text-template','application/vnd.oasis.opendocument.spreadsheet-template','application/vnd.oasis.opendocument.presentation-template')))
SERVICES = dict(zip(FORMATS,('com.sun.star.text.TextDocument','com.sun.star.sheet.SpreadsheetDocument','com.sun.star.presentation.PresentationDocument')))
FILTERS = dict(zip(FORMATS,('writer8_template','calc8_template','impress8_template')))
BASE_FORMAT = dict(zip(FORMATS,('odt','ods','odp')))
PROFILE = 'own_synthetic_odf13_aes256cbc_pbkdf2sha1_4096'
MEMBERS = ['META-INF/manifest.xml','Pictures/retained.bin','content.xml','meta.xml','mimetype','settings.xml','styles.xml']
ENCRYPTED = ['content.xml','meta.xml','settings.xml','styles.xml']
MAPPING = {'dev':'st_dev','ino':'st_ino','mode':'st_mode','uid':'st_uid','nlink':'st_nlink','bytes':'st_size','mtime_ns':'st_mtime_ns','ctime_ns':'st_ctime_ns'}

def need(value, code):
    if not value: raise ValueError(code)

def decode(raw):
    def pairs(items):
        result = {}
        for key,value in items:
            need(key not in result, 'DUPLICATE_JSON_KEY'); result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda _:need(False,'JSON_CONSTANT'))

def same(a,b):
    return json.dumps(a,sort_keys=True,separators=(',',':')) == json.dumps(b,sort_keys=True,separators=(',',':'))

def metadata(path, recorded):
    """No open/read/hash; compare every upstream field and add current gid."""
    path = Path(path)
    need(path.is_absolute() and path == path.resolve(strict=True) and '..' not in path.parts, 'CANONICAL_METADATA_PATH')
    for parent in path.parents:
        if parent == Path('/home/jericho/.cache'): break
        s = parent.lstat()
        need(stat.S_ISDIR(s.st_mode) and s.st_uid==os.getuid() and stat.S_IMODE(s.st_mode)==0o700,'PRIVATE_METADATA_PARENT')
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1 and stat.S_IMODE(info.st_mode)==0o600, 'PRIVATE_METADATA_FILE')
    need(set(recorded)==set(MAPPING), 'UPSTREAM_CUSTODY_FIELDS')
    for key,field in MAPPING.items():
        actual = oct(stat.S_IMODE(info.st_mode)) if key=='mode' else getattr(info,field)
        need(type(actual) is type(recorded[key]) and actual==recorded[key], 'UPSTREAM_METADATA_CAS')
    return [getattr(info,k) for k in IDENTITY_FIELDS]

def safe_read(path, expected):
    """Only three exact nonsecret files; credentials/ciphertext cannot enter."""
    path = Path(path)
    allowed = {str(RESULT_PATH):RESULT_SHA,str(ACCEPT_PATH):ACCEPT_SHA,str(SPEC_PATH):SPEC_SHA}
    need(allowed.get(str(path))==expected, 'SAFE_RECEIPT_ALLOWLIST')
    need(path==path.resolve(strict=True) and not any(p.is_symlink() for p in (path,*path.parents)), 'SAFE_RECEIPT_PATH')
    fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        before=os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600 and 0<before.st_size<=1024**2, 'SAFE_RECEIPT_CUSTODY')
        with os.fdopen(fd,'rb',closefd=False) as stream: raw=stream.read(1024**2+1)
        ident=[getattr(before,k) for k in IDENTITY_FIELDS]
        need(ident==[getattr(os.fstat(fd),k) for k in IDENTITY_FIELDS]==[getattr(path.lstat(),k) for k in IDENTITY_FIELDS] and len(raw)==before.st_size, 'SAFE_RECEIPT_CAS')
    finally: os.close(fd)
    need(hashlib.sha256(raw).hexdigest()==expected, 'SAFE_RECEIPT_SHA')
    return raw,dict(path=str(path),bytes=len(raw),sha256=expected,identity=ident)

def build(result, accepted, receipt_pins, identities):
    """Pure mapping. Caller establishes exact safe-receipt SHA before calling."""
    need(result.get('schema')=='friday.f06.odf-template-native-paths.v1' and result.get('assignment')==NATIVE_ASSIGNMENT and result.get('status')=='OTS_OTP_NATIVE_PASS_OTT_RETAINED_READ_ORACLE_PASS','NATIVE_RECEIPT_LINEAGE')
    need(result.get('native_unmocked') is True and result.get('application_acceptance')=='NOT_RUN' and result.get('bot_acceptance')=='NOT_RUN' and result.get('formal_F06')=='NOT_CLAIMED','NATIVE_RECEIPT_SCOPE')
    need(accepted.get('schema')=='friday.f06.odf-template.native.rootacceptance.v1' and accepted.get('state')=='BOUNDED_OTS_OTP_NATIVE_ACCEPTED_OTT_RETAINED_EFFECT_AND_READONLY_ORACLE_ACCEPTED' and accepted.get('all_checks_pass') is True,'NATIVE_ROOT_ACCEPTANCE')
    need(accepted.get('source_result')=={'path':str(RESULT_PATH),'sha256':RESULT_SHA},'NATIVE_ROOT_RESULT_JOIN')
    for name,path,digest in [('native_result',RESULT_PATH,RESULT_SHA),('native_root_acceptance',ACCEPT_PATH,ACCEPT_SHA),('fixture_spec',SPEC_PATH,SPEC_SHA)]:
        pin=receipt_pins[name]
        need(pin.get('path')==str(path) and pin.get('sha256')==digest and type(pin.get('bytes')) is int and pin['bytes']>0,'SAFE_PIN_JOIN')
    need(set(receipt_pins)=={'native_result','native_root_acceptance','fixture_spec'},'SAFE_PIN_SET')
    rows=result.get('rows');need(type(rows) is list and [r.get('format') for r in rows]==list(FORMATS),'NATIVE_THREE_ROWS')
    need(result.get('first_attempt_reconciliation',{}).get('output_effect_repeat') is False and result.get('cleanup',{}).get('all_actor_processes_absent') is True,'NATIVE_EFFECT_AND_CLOSURE')
    credential=result['credential'];expected_credential=str(NATIVE_ROOT/'SYNTHETIC-CREDENTIAL.json')
    need(credential.get('path')==expected_credential and credential.get('custody',{}).get('bytes')==115 and credential.get('values_logged') is False and credential.get('argv_or_env') is False,'SYNTHETIC_CREDENTIAL_METADATA')
    credential_ref=dict(path=expected_credential,bytes=115,identity=identities[expected_credential],sha256=None)
    need(len(credential_ref['identity'])==9 and credential_ref['identity'][6]==115,'CREDENTIAL_FULL_METADATA')
    fixtures=[]
    for row in rows:
        fmt=row['format'];need(row.get('all_checks_pass') is True,'NATIVE_ROW_RECORDED_CHECKS')
        source=row['fixture'];output=row['output']
        need(source['path']!=output['path'] and source['sha256']!=output['sha256'],'SOURCE_OUTPUT_DISTINCT')
        for role,original in [('source',source),('output',output)]:
            expected=NATIVE_ROOT/'authority/profiles/odf-template-a/workspace'/('own-source.'+fmt if role=='source' else 'own-edited.'+fmt)
            need(original.get('path')==str(expected) and re.fullmatch('[0-9a-f]{64}',original.get('sha256','')) is not None,'EXACT_TEMPLATE_PATH_SHA')
            structure=original['structure']
            need(structure.get('format')==fmt and structure.get('mime')==MIMES[fmt] and structure.get('members')==MEMBERS and structure.get('encrypted_members')==ENCRYPTED and structure.get('rounds')==4096 and structure.get('algorithm')=='http://www.w3.org/2001/04/xmlenc#aes256-cbc','EXACT_TEMPLATE_STRUCTURE')
            ident=identities[str(expected)];need(type(ident) is list and len(ident)==9 and ident[6]==original['identity']['bytes'],'TEMPLATE_FULL_METADATA')
            fixtures.append(dict(fixture_id='template-'+fmt+'-'+role,format=fmt,fixture_profile=PROFILE,role=role,semantic='BEFORE' if role=='source' else 'AFTER',mime=MIMES[fmt],service=SERVICES[fmt],filter=FILTERS[fmt],staged_name='retained-'+role+'.'+fmt,path=str(expected),bytes=original['identity']['bytes'],sha256=original['sha256'],identity=ident,native_source_ciphertext=dict(path=source['path'],bytes=source['identity']['bytes'],sha256=source['sha256'],identity=identities[source['path']]),native_structure=structure))
    need(tuple(r['fixture_id'] for r in fixtures)==IDS,'EXACT_SIX_SOURCE_OUTPUT_ROWS')
    return dict(schema=SCHEMA,state='FROZEN_RETAINED_METADATA_NOT_EXECUTION_AUTHORITY',assignment=ASSIGNMENT,native_assignment=NATIVE_ASSIGNMENT,lineage_mode='own_synthetic_template_native_retained',semantic=SEMANTIC,selected_fixture_ids=list(IDS),selected_count=6,fixtures=fixtures,credential=credential_ref,proofs=receipt_pins,expected_Office_stores=0,expected_Office_password_probes=18,expected_Office_starts_maximum=3,as_template=False,installed_source_receipt_sha256=result['source_receipt_sha256'],installed_native_source=result['installed_source'],installed_version=result['actual'],historical_ott_raw_edit_receipt='NOT_RETAINED_DO_NOT_RECONSTRUCT_OR_REPLAY',native_effects_repeated=False,application_acceptance='NOT_RUN',bot_acceptance='NOT_RUN',whole_F06_accepted=False,credential_sha256_basis='UNBOUND_NOT_READ; future admitted unit computes copy digest after frozen full metadata CAS')

def build_from_safe_receipts():
    raw,rpin=safe_read(RESULT_PATH,RESULT_SHA);result=decode(raw)
    raw,apin=safe_read(ACCEPT_PATH,ACCEPT_SHA);accepted=decode(raw)
    _,spin=safe_read(SPEC_PATH,SPEC_SHA)
    identities={}
    for row in result['rows']:
        for key in ('fixture','output'):
            ref=row[key];identities[ref['path']]=metadata(ref['path'],ref['identity'])
    ref=result['credential'];identities[ref['path']]=metadata(ref['path'],ref['custody'])
    return build(result,accepted,dict(native_result=rpin,native_root_acceptance=apin,fixture_spec=spin),identities)

def validate(manifest):
    need(same(manifest,build_from_safe_receipts()),'EXACT_FROZEN_TEMPLATE_MANIFEST')
    return manifest
