"""Dormant six-template readonly oracle; Root alone admits existing finite frame.
No producer/store branch. Typed PyUNO/callback helpers are unchanged.
"""
import argparse,base64,hashlib,json,os,stat,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
import template_adapter as t

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def private_root(raw):
 p=Path(raw)
 if not p.is_absolute() or '..'in p.parts or p!=p.resolve(strict=True):raise ValueError('root_not_canonical')
 s=p.lstat()
 if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or stat.S_IMODE(s.st_mode)!=0o700:raise ValueError('private_root_required')
 return p

def private_file(raw,root):
 p=Path(raw)
 if '..'in p.parts or not p.is_absolute() or not p.is_relative_to(root) or p!=p.resolve(strict=True):raise ValueError('file_not_canonical_within_root')
 for parent in [p.parent,*p.parent.parents]:
  s=parent.lstat()
  if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or stat.S_IMODE(s.st_mode)!=0o700:raise ValueError('private_directory_required')
  if parent==root:break
 s=p.lstat()
 if not stat.S_ISREG(s.st_mode) or s.st_uid!=os.getuid() or s.st_nlink!=1 or stat.S_IMODE(s.st_mode)!=0o600:raise ValueError('private_file_required')
 return p

def retained_native_inputs(root,expected):
 manifest=private_file(root/'NATIVE-OUTPUTS.json',root)
 t.need(type(expected)is str and len(expected)==64 and all(c in '0123456789abcdef'for c in expected) and sha(manifest)==expected,'native_manifest_pin')
 obj=t.decode(manifest.read_bytes());rows=obj.get('fixtures')
 t.need(obj.get('schema')==t.SCHEMA and obj.get('state')=='FROZEN_RETAINED_METADATA_NOT_EXECUTION_AUTHORITY' and obj.get('assignment')==t.ASSIGNMENT and obj.get('semantic')==t.SEMANTIC and obj.get('as_template')is False,'template_manifest_schema')
 t.need(obj.get('selected_fixture_ids')==list(t.IDS) and type(obj.get('selected_count'))is int and obj['selected_count']==6 and type(rows)is list and len(rows)==6,'template_six_pairs')
 selected=[];names=[]
 for ident,row in zip(t.IDS,rows):
  fmt,role=ident.split('-')[1:];name='retained-'+role+'.'+fmt
  t.need(row.get('fixture_id')==ident and row.get('format')==fmt and row.get('role')==role and row.get('fixture_profile')==t.PROFILE and row.get('semantic')==('BEFORE'if role=='source'else'AFTER') and row.get('staged_name')==name and row.get('mime')==t.MIMES[fmt] and row.get('service')==t.SERVICES[fmt] and row.get('filter')==t.FILTERS[fmt],'template_typed_row')
  p=private_file(root/'native-outputs'/name,root)
  t.need(type(row.get('bytes'))is int and 0<row['bytes']<=1000000 and p.stat().st_size==row['bytes'] and sha(p)==row.get('sha256'),'template_existing_bytes_pin')
  selected.append((row,p,fmt));names.append(name)
 t.need({p.name for p in (root/'native-outputs').iterdir()}==set(names),'template_exact_directory')
 return manifest,obj,selected

def envelope(path,row):
 ns='{urn:oasis:names:tc:opendocument:xmlns:manifest:1.0}'
 with zipfile.ZipFile(path)as z:
  infos=z.infolist();names=z.namelist()
  t.need(len(names)==len(set(names)) and sorted(names)==t.MEMBERS and infos[0].filename=='mimetype' and infos[0].compress_type==zipfile.ZIP_STORED and not infos[0].extra and all(not i.flag_bits&1 for i in infos),'template_zip_structure')
  t.need(z.read('mimetype').decode('ascii')==row['mime'],'template_mime')
  raw=z.read('META-INF/manifest.xml')
  t.need(b'<!DOCTYPE'not in raw.upper() and b'<!ENTITY'not in raw.upper(),'manifest_dtd')
  manifest=ET.fromstring(raw);entries=list(manifest);paths=[e.get(ns+'full-path')for e in entries]
  t.need(len(paths)==len(set(paths)),'manifest_unique_paths')
  roots=[e for e in entries if e.get(ns+'full-path')=='/']
  t.need(len(roots)==1 and roots[0].get(ns+'media-type')==row['mime'],'template_manifest_mime')
  encrypted=[];salts={};ivs={}
  for entry in entries:
   enc=entry.find(ns+'encryption-data')
   if enc is None:continue
   name=entry.get(ns+'full-path');alg=enc.find(ns+'algorithm');kd=enc.find(ns+'key-derivation');start=enc.find(ns+'start-key-generation')
   t.need(name in t.ENCRYPTED and alg is not None and kd is not None and start is not None and z.getinfo(name).compress_type==zipfile.ZIP_STORED,'template_encryption_descriptor')
   t.need(alg.get(ns+'algorithm-name')=='http://www.w3.org/2001/04/xmlenc#aes256-cbc' and kd.get(ns+'key-derivation-name')=='PBKDF2' and kd.get(ns+'key-size')=='32' and kd.get(ns+'iteration-count')=='4096' and start.get(ns+'start-key-generation-name')=='http://www.w3.org/2000/09/xmldsig#sha256' and start.get(ns+'key-size')=='32' and enc.get(ns+'checksum-type')==ns[1:-1]+'#sha256-1k','template_exact_synthetic4096_profile')
   salt=base64.b64decode(kd.get(ns+'salt'),validate=True);iv=base64.b64decode(alg.get(ns+'initialisation-vector'),validate=True)
   t.need(len(salt)==len(iv)==16,'template_salt_iv_size')
   salts[name]=hashlib.sha256(salt).hexdigest();ivs[name]=hashlib.sha256(iv).hexdigest();encrypted.append(name)
  t.need(sorted(encrypted)==t.ENCRYPTED and salts==row['native_structure']['salts_sha256'] and ivs==row['native_structure']['ivs_sha256'],'template_retained_encrypted_structure')
 return dict(container='ODF_TEMPLATE',mime=row['mime'],fixture_profile=t.PROFILE,rounds=4096,encrypted_members=sorted(encrypted),salts_sha256=salts,ivs_sha256=ivs,DefaultVersion='NOT_CLAIMED',checksum_authenticity='NOT_A_SIGNATURE',source='independent descriptor only; same-byte Office correct semantics still required')

def semantic(doc,row):
 fmt=row['format'];after=row['role']=='output'
 if not doc.supportsService(row['service']):return False
 if fmt=='ott':return doc.getText().getString().splitlines()==['OTT-UNIQUE-AFTER'if after else'OTT-UNIQUE-BEFORE','RETAINED-TEXT-PARAGRAPH']
 if fmt=='ots':
  sheets=doc.getSheets()
  if sheets.getCount()!=1 or not sheets.hasByName('TemplateSheet'):return False
  sheet=sheets.getByName('TemplateSheet');a1=sheet.getCellRangeByName('A1');b1=sheet.getCellRangeByName('B1')
  cursor=sheet.createCursor();cursor.gotoStartOfUsedArea(False);cursor.gotoEndOfUsedArea(True);used=cursor.getRangeAddress()
  return a1.getString()==('OTS-AFTER'if after else'OTS-BEFORE') and b1.getValue()==17 and b1.getString()=='17' and a1.getType().value=='TEXT' and b1.getType().value=='VALUE' and (used.StartColumn,used.StartRow,used.EndColumn,used.EndRow)==(0,0,1,0)
 pages=doc.getDrawPages()
 if pages.getCount()!=2:return False
 wanted=['OTP-UNIQUE-AFTER'if after else'OTP-UNIQUE-BEFORE','RETAINED-SECOND-SLIDE']
 for index,text in enumerate(wanted):
  page=pages.getByIndex(index)
  if page.getCount()!=1 or page.getByIndex(0).getString()!=text:return False
 return True

def atomic_result(path,value):
 tmp=path.with_name(path.name+'.next');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'w')as f:json.dump(value,f,ensure_ascii=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 if os.path.lexists(path):private_file(path,path.parent)
 os.replace(tmp,path);d=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(d)
 finally:os.close(d)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',required=True);ap.add_argument('--input-root',required=True);ap.add_argument('--credential-ref',required=True);ap.add_argument('--uno-pipe',required=True);ap.add_argument('--mode',choices=['verify-native-edits'],required=True);ap.add_argument('--input-manifest-sha256',required=True);a=ap.parse_args()
 os.umask(0o077);root=private_root(a.root);input_root=private_root(a.input_root)
 t.need(a.uno_pipe.startswith('f06_') and a.uno_pipe.replace('_','').isalnum(),'dedicated_pipe_required')
 manifest,retained,selected=retained_native_inputs(input_root,a.input_manifest_sha256)
 cred=private_file(a.credential_ref,input_root);secret=t.decode(cred.read_bytes());password=secret['password'];wrong=secret['wrong_password']
 t.need(type(password)is str and type(wrong)is str and bool(password) and bool(wrong) and password!=wrong,'credential_contract')
 import uno,unohelper
 from request_args_compat_v2 import install_request_args_compat
 from callback_observer_v2 import make_abort_handler,observed_password_refusal_sequence,safe_exception
 install_request_args_compat(uno)
 from com.sun.star.beans import PropertyValue
 from com.sun.star.task import XInteractionHandler,DocumentPasswordRequest,DocumentMSPasswordRequest
 handler=make_abort_handler(uno,unohelper,XInteractionHandler,DocumentPasswordRequest,DocumentMSPasswordRequest,uno.getClass('com.sun.star.task.ErrorCodeRequest2'))
 def prop(name,value):p=PropertyValue();p.Name=name;p.Value=value;return p
 local=uno.getComponentContext();resolver=local.ServiceManager.createInstanceWithContext('com.sun.star.bridge.UnoUrlResolver',local)
 remote=resolver.resolve('uno:pipe,name='+a.uno_pipe+';urp;StarOffice.ComponentContext');desktop=remote.ServiceManager.createInstanceWithContext('com.sun.star.frame.Desktop',remote)
 def probe(path,row,supplied):
  doc=None;start=len(handler.events);answer=dict(opened=False,semantic_match=False,expected_password_refusal=False)
  try:
   props=[prop('Hidden',True),prop('ReadOnly',True),prop('AsTemplate',False),prop('MacroExecutionMode',0),prop('UpdateDocMode',0),prop('InteractionHandler',handler)]
   if supplied is not None:props.append(prop('Password',supplied))
   doc=desktop.loadComponentFromURL(uno.systemPathToFileUrl(str(path)),'_blank',0,tuple(props))
   if doc is not None:
    answer['opened']=True
    try:answer['semantic_match']=bool(semantic(doc,row))
    except Exception as error:answer['semantic_exception']=safe_exception(error)
  except Exception as error:answer['load_exception']=safe_exception(error)
  finally:
   answer['interaction_events']=handler.events[start:]
   if doc is not None:
    try:doc.close(True)
    except Exception:doc.dispose()
  answer['expected_password_refusal']=not answer['opened'] and 'load_exception'not in answer and observed_password_refusal_sequence(answer['interaction_events'],t.BASE_FORMAT[row['format']])
  return answer
 out=root/'native-edit-oracle';out.mkdir(mode=0o700,exist_ok=False);rows=[]
 for source,path,fmt in selected:
  before=sha(path);t.need(before==source['sha256'],'template_source_before_pin')
  descriptor=None;envelope_error=None
  try:descriptor=envelope(path,source)
  except Exception as error:envelope_error=type(error).__name__
  tests=dict(missing=probe(path,source,None),wrong=probe(path,source,wrong),correct=probe(path,source,password))
  unchanged=sha(path)==before
  passed=unchanged and envelope_error is None and tests['missing']['expected_password_refusal'] and tests['wrong']['expected_password_refusal'] and tests['correct']['opened'] and tests['correct']['semantic_match'] and not tests['correct']['interaction_events']
  rows.append(dict(fixture_id=source['fixture_id'],format=fmt,fixture_profile=t.PROFILE,filter=source['filter'],source_path=str(path),source_sha256=before,path=str(path),sha256=before,bytes=path.stat().st_size,independent_office_password_and_semantics_pass=passed,tests=tests,envelope=descriptor,envelope_exception_class=envelope_error,same_input_bytes_preserved=unchanged,credential_ref=str(cred),new_bytes=False,recovered_old_bytes=False,native_protected_result='PRESERVED_SYNTHETIC_NATIVE_FACTS; OTT raw edit receipt NOT_RETAINED'))
  result=dict(mode=a.mode,input_manifest=str(manifest),input_manifest_sha256=a.input_manifest_sha256,rows=rows,planned_rows=6,whole_seven_covered=False,all_pass=len(rows)==6 and all(r['independent_office_password_and_semantics_pass']for r in rows),oracle='same fixed private LibreOffice bank, dedicated readonly UNO pipe',visual_fidelity='NOT_TESTED',F06_formal_or_delivery='NOT_RUN',all_pass_scope='SELECTED_ONLY',selected_fixture_ids=list(t.IDS),selected_count=6,full_six_covered=False,all_seven_pass=False,whole_F06_accepted=False)
  atomic_result(out/'RESULT.json',result)
  t.need(unchanged,'template_source_changed')
 print(json.dumps(dict(fixtures=len(rows),passed=sum(r['independent_office_password_and_semantics_pass']for r in rows))))
 return 0 if all(r['independent_office_password_and_semantics_pass']for r in rows)else 1

if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as error:print(json.dumps(dict(status='ERROR',exception_class=type(error).__name__)));raise SystemExit(2)
