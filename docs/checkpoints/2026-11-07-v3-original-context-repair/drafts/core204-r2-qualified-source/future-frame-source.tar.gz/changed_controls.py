"""Pure changed-scope controls. Never import actor, recovery, builder or product.
Only safe metadata module definitions and selected AST fragments run on own fixtures.
"""
from pathlib import Path
import ast, copy, datetime, hashlib, importlib.util, json, os, resource, shutil, stat, time, types
os.umask(0o077)
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
affinity=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,affinity[:2])
start=time.monotonic();deadline=start+90
B=Path(__file__).resolve().parent
OLD=Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-ROOT-MAINTENANCE-FRAME-20261111')
R2=Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-STARTUP-OBSERVER-R2-20261112/candidate/run_native204_once.py')
checks=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(name,fn):
 assert time.monotonic()<deadline
 fn();checks.append({'name':name,'state':'PASS'})
def require(v):assert v
def refuses(fn,classes=(AssertionError,ValueError,FileNotFoundError,KeyError,TypeError)):
 try:fn()
 except classes as e:return type(e).__name__
 raise AssertionError('expected_refusal_missing')
def tree(name):return ast.parse((B/name).read_text())
def func(t,name):return next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name)
def dump(n):return ast.dump(n,include_attributes=False)
actor=tree('run_native204_once.py');recovery=tree('resume_native204_services.py');base=ast.parse(R2.read_text())
spec=importlib.util.spec_from_file_location('future204_pure_metadata',B/'root204_metadata.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def ast_closure():
 # All actor function definitions, including cleanup, are exact reviewed R2.
 for node in base.body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
   other=next(n for n in actor.body if type(n) is type(node) and n.name==node.name)
   assert dump(node)==dump(other),node.name
 assert dump(func(recovery,'publisher_terminal_proven'))==dump(func(actor,'publisher_terminal_proven'))
 # Core metadata functions/guards are unchanged; only ORIGIN_POLICY hash retargets.
 oldm=ast.parse((OLD/'root204_metadata.py').read_text())
 for node in oldm.body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
   other=next(n for n in tree('root204_metadata.py').body if type(n) is type(node) and n.name==node.name)
   assert dump(node)==dump(other),node.name
check('reviewed_R2_actor_all_functions_and_recovery_terminal_exactAST_metadata_all_guards_unchanged',ast_closure)
def pins():
 assert m.B==B and m.ORIGIN_POLICY=={'path':str(B/'ROOT-204-PUBLIC-ORIGIN-POLICY.json'),'sha256':sha(B/'ROOT-204-PUBLIC-ORIGIN-POLICY.json')}
 policy=m.readref(m.ORIGIN_POLICY)
 assert policy['published_snapshot']=='48de25314b76528b8525674097947a45750c46d3'
 oldpolicy=json.loads((OLD/'ROOT-204-PUBLIC-ORIGIN-POLICY.json').read_bytes())
 assert {k:v for k,v in policy.items() if k!='retained_executed_sources'}=={k:v for k,v in oldpolicy.items() if k!='retained_executed_sources'}
 for row in policy['retained_executed_sources'].values():
  assert sha(row['path'])==row['sha256']
 for name in ('publication/build-layer-publication-request.py','publication/friday_v3_layer_publication.py','admission-retained/observe-current-retained-units.py'):
  assert (B/name).read_bytes()==(OLD/name).read_bytes()
 text=(B/'run_native204_once.py').read_text()
 assert "assert sha(B / 'root204_metadata.py') == "+repr(sha(B/'root204_metadata.py')) in text
 assert "assert sha(RESTORE) == "+repr(sha(B/'resume_native204_services.py')) in text
 assert "assert sha(CP) == "+repr(sha(B/'publication/friday_v3_layer_publication.py')) in text
 assert "PUB = 'frw-astra-native204-install-r2-20261112.service'" in text
 assert "PUB = 'frw-astra-native204-install-r2-20261112.service'" in (B/'resume_native204_services.py').read_text()
check('complete_hashlinks_policy_join_and_distinct_PUB_byteexact_builder_publisher_observer',pins)
def template_slots():
 for role in ('FRESH-ADMISSION','FRESH-READBACK','SOURCE-ACCEPTANCE','MINIMUM-BANK-PROFILE-QUALIFICATION'):
  value=json.loads((B/f'ROOT-204-{role}-TEMPLATE.json').read_bytes())
  assert value['template_only_no_execution_grant'] is True and value['state'].startswith('TEMPLATE_')
  assert str(OLD) not in json.dumps(value)
 admission=json.loads((B/'ROOT-204-FRESH-ADMISSION-TEMPLATE.json').read_bytes())
 for key,name in [('actor','run_native204_once.py'),('recovery','resume_native204_services.py')]:
  assert admission[key]=={'path':str(B/name),'sha256':sha(B/name)}
 absent=['ROOT-FRESH-REQUEST.json','ROOT-204-SOURCE-ACCEPTANCE.json','ROOT-204-FRESH-READBACK.json','ROOT-204-FRESH-ADMISSION.json','ROOT-204-BOUND-INPUTS.json','ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION.json','ROOT-NATIVE204-LIVE-OPERATION.json','ROOT-NATIVE204-CUSTODY-RELEASE.json','admission-retained/READONLY-RETAINED-UNITS-INTENT.json','admission-retained/ROOT-ACTUAL-RETAINED-UNIT-OBSERVATIONS.json']
 assert all(not os.path.lexists(B/name) for name in absent)
 commands=json.loads((B/'ROOT-FUTURE-COMMANDS.json').read_bytes())
 for argv in commands['commands'].values():assert not any(str(OLD) in x for x in argv)
 argv=commands['commands']['builder'];assert argv[argv.index('--layer')+1]==m.LAYER
 assert argv[argv.index('--seconds')+1]=='600' and argv[argv.index('--output')+1]==str(B/'ROOT-FRESH-REQUEST.json')
check('all_fresh_authority_slots_absent_templates_false_paths_local_explicit_single_layer600',template_slots)
def preserved_topflow():
 # Retargeting changes only PUB and two linked file hashes in the actor top level.
 before=R2.read_text();after=(B/'run_native204_once.py').read_text()
 expected=before.replace("PUB = 'frw-astra-native204-publication-20261111.service'","PUB = 'frw-astra-native204-install-r2-20261112.service'")
 expected=expected.replace(sha(OLD/'root204_metadata.py'),sha(B/'root204_metadata.py')).replace(sha(OLD/'resume_native204_services.py'),sha(B/'resume_native204_services.py'))
 assert after==expected
 assert "assert not os.path.lexists(tx)" in after
 assert after.index("j['publisher_launch_consumed_no_retry'] = True")<after.index('r = run_owned_publisher(args,')
 assert "os.O_EXCL" in after and "--property=RuntimeMaxSec=810" in after
 assert "new_artificial_lifetime_timer=False" in after
 assert "current_unit['RuntimeMaxUSec'] == 'infinity'" in after
check('strict203_predecessor_CAS_fullread_guardedrollback_once_custody_finiteconsumer_permanentlifetime_preserved',preserved_topflow)
fixture=B/'pure-fixtures';fixture.mkdir(mode=0o700)
try:
 def reference_controls():
  p=fixture/'pin.json';p.write_bytes(m.encoded({'source':'fixture_only'}));p.chmod(0o600)
  r=m.reference(p);assert m.readref(r)=={'source':'fixture_only'}
  p.write_bytes(m.encoded({'source':'changed'}));assert refuses(lambda:m.readref(r))=='InvalidBinding'
  symlink=fixture/'alias.json';symlink.symlink_to(p);assert refuses(lambda:m.reference(symlink))=='InvalidBinding'
  hardlink=fixture/'hard.json';os.link(p,hardlink);assert refuses(lambda:m.reference(p))=='InvalidBinding';hardlink.unlink()
  assert refuses(lambda:m.readref({'path':str(p),'sha256':sha(p),'nonce':'bypass'}))=='InvalidBinding'
 check('real_metadata_reference_hash_symlink_hardlink_extra_field_negatives',reference_controls)
 def txguard():
  guard=next(n for n in actor.body if isinstance(n,ast.Assert) and ast.unparse(n.test)=='not os.path.lexists(tx)')
  ns={'os':os,'tx':fixture/'tx'};code=compile(ast.Module(body=[guard],type_ignores=[]),'<exact-actor-no-tx-guard>','exec')
  exec(code,ns)
  ns['tx'].mkdir(mode=0o700);assert refuses(lambda:exec(code,ns))=='AssertionError';ns['tx'].rmdir()
  ns['tx'].symlink_to(fixture/'absent');assert refuses(lambda:exec(code,ns))=='AssertionError';ns['tx'].unlink()
  cp=tree('publication/friday_v3_layer_publication.py')
  run=func(cp,'run');guards=[n for n in ast.walk(run) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='require' and len(n.args)>1 and ast.unparse(n.args[0])=='not os.path.lexists(current_transaction)']
  assert len(guards)==1
  expr=ast.Expression(guards[0]);code=compile(expr,'<exact-publisher-no-tx-guard>','eval')
  ns={'os':os,'current_transaction':fixture/'tx','require':lambda v,why:require(v)};eval(code,ns)
  ns['current_transaction'].mkdir(mode=0o700);assert refuses(lambda:eval(code,ns))=='AssertionError';ns['current_transaction'].rmdir()
 check('exact_actor_and_publisher_unconsumed_txguards_refuse_existing_or_dangling_transaction_no_intent_needed',txguard)
 def recovery_environment():
  update=next(n for n in recovery.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='os.environ.update')
  fake=types.SimpleNamespace(environ={'HERMES_HOME':'wrong_fixture_home'})
  ns={'os':fake,'H':m.H};exec(compile(ast.Module(body=[update],type_ignores=[]),'<recovery-explicit-home>','exec'),ns)
  assert fake.environ['HERMES_HOME']==str(m.H)
  assert fake.environ['HERMES_GATEWAY_LOCK_DIR']=='/home/jericho/.local/state/hermes/gateway-locks'
  assert fake.environ['GIT_OPTIONAL_LOCKS']=='0' and fake.environ['PYTHONDONTWRITEBYTECODE']=='1'
  # The exact command helper inherits this environment and retains deadline logic.
  calls=[]
  def run(args,**kw):calls.append((dict(fake.environ),kw));return types.SimpleNamespace(returncode=0)
  ns.update(subprocess=types.SimpleNamespace(run=run),origin=10,remaining=lambda end,sec:min(end-20,sec))
  exec(compile(ast.Module(body=[func(recovery,'command')],type_ignores=[]),'<recovery-command>','exec'),ns)
  ns['command'](['fixture-status'],30,deadline=100)
  assert calls[0][0]['HERMES_HOME']==str(m.H) and calls[0][1]['timeout']==30 and calls[0][1]['check'] is False
 check('exact_recovery_env_overrides_foreignhome_command_inherits_realhome_and_finite_deadline',recovery_environment)
 def raw_exit_before_refusal():
  assign=next(n for n in ast.walk(recovery) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Subscript) and isinstance(t.slice,ast.Constant) and t.slice.value=='last_dashboard_status_returncode' for t in n.targets))
  saved=next(n for n in ast.walk(recovery) if isinstance(n,ast.Expr) and n.lineno==assign.end_lineno+1)
  refusal=next(n for n in ast.walk(recovery) if isinstance(n,ast.Assert) and isinstance(n.msg,ast.Constant) and n.msg.value=='dashboard_saved_phase_status_unknown')
  snapshots=[];phase={};ns={'phase':phase,'status':types.SimpleNamespace(returncode=73),'save':lambda:snapshots.append(copy.deepcopy(phase))}
  code=compile(ast.Module(body=[assign,saved,refusal],type_ignores=[]),'<exact-recovery-status-retention>','exec')
  assert refuses(lambda:exec(code,ns))=='AssertionError'
  assert snapshots==[{'last_dashboard_status_returncode':73}]
 check('future_raw_dashboard_exit_recorded_before_actual_nonzero_refusal_no_stdout_saved',raw_exit_before_refusal)
 # Exercise safe join checks on synthetic in-memory fixtures, not current proofs.
 def join_negatives():
  readref,validate,origin=m.readref,m.validate_source_request,m.validate_snapshot_origin
  m.readref=lambda ref:{};m.validate_source_request=lambda request:{'expected_receipt_sha256':'fixture'};m.validate_snapshot_origin=lambda a,s:{'fixture_only':True}
  current=1700000000.0;boot='fixture-boot';stamp=datetime.datetime.fromtimestamp(current,datetime.timezone.utc).isoformat()
  a=json.loads((B/'ROOT-204-SOURCE-ACCEPTANCE-TEMPLATE.json').read_bytes());a.update(state=a.pop('required_state_after_actual_Root_review'),accepted=True,template_only_no_execution_grant=False,all_four_current_source_gates_accepted=True,gate_retry_history_preserved=True,final_source_result={'path':str(m.S/'RESULT.json'),'sha256':'a'*64})
  s=json.loads((B/'ROOT-204-FRESH-READBACK-TEMPLATE.json').read_bytes());s.update(state=s.pop('required_state_after_actual_Root_readback'),template_only_no_execution_grant=False,boot_id=boot,observed_at_moscow=stamp,head='b'*40,checks={key:True for key in m.SNAPSHOT_TRUE_FIELDS},services={name:{'boot_id':boot,'pid':100,'birth_ticks':200,'invocation_id':'c'*32,'cgroup':'/user.slice/fixture','enabled_active':True,'runtime_max':'infinity'} for name in ('gateway','dashboard')})
  try:
   assert m.validate_join({},a,s,now=current,boot_id=boot)['state']=='PURE_METADATA_BOUND_NOT_ADMISSION'
   for key in ('current_request_unconsumed','old_effects_not_replayed','cancellation_clear','no_current_maintenance'):
    bad=copy.deepcopy(s);bad['checks'][key]=False;assert refuses(lambda:m.validate_join({},a,bad,now=current,boot_id=boot))=='InvalidBinding'
   for name,change in [('stale',lambda v:v.update(observed_at_moscow=datetime.datetime.fromtimestamp(current-301,datetime.timezone.utc).isoformat())),('wrongboot',lambda v:v.update(boot_id='other')),('permanentTTL',lambda v:v['services']['gateway'].update(runtime_max='1800s'))]:
    bad=copy.deepcopy(s);change(bad);assert refuses(lambda:m.validate_join({},a,bad,now=current,boot_id=boot))=='InvalidBinding'
   bad=copy.deepcopy(a);bad['gate_retry_history_preserved']=False;assert refuses(lambda:m.validate_join({},bad,s,now=current,boot_id=boot))=='InvalidBinding'
  finally:m.readref,m.validate_source_request,m.validate_snapshot_origin=readref,validate,origin
 check('pure_synthetic_join_refuses_consumed_history_false_unconsumed_stale_wrongboot_productTTL',join_negatives)
finally:shutil.rmtree(fixture)
def deterministic_request():
 b=tree('publication/build-layer-publication-request.py')
 default=next(n for n in b.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LAYER_NAMES' for t in n.targets))
 assert len(ast.literal_eval(default.value))==4
 build=func(b,'build_request');assert not any(isinstance(n,ast.Attribute) and n.attr=='output' for n in ast.walk(build))
 text=ast.get_source_segment((B/'publication/build-layer-publication-request.py').read_text(),build)
 assert not any(token in text for token in ('datetime','urandom','uuid','time.time','time.monotonic'))
 assert "json.dumps(value, sort_keys=True, indent=2)" in (B/'publication/build-layer-publication-request.py').read_text()
 assert all(not isinstance(n,(ast.Import,ast.ImportFrom)) or all(a.name not in ('uuid','datetime','time') for a in n.names) for n in b.body)
check('static_deterministic_builder_sameargs_pins_history_same_rawhash_output_path_absent_defaultfour_unchanged',deterministic_request)
for path in B.rglob('*.py'):ast.parse(path.read_text())
out={'schema':'frw.future204-r2.pure-source-controls.v1','state':'PURE_SOURCE_CONTROLS_PASS_NOT_LIVE_ACCEPTANCE','checks':checks,'count':len(checks),'fixture_removed':not fixture.exists(),'limits':{'wall_seconds':90,'CPU_seconds':60,'address_space_bytes':512*1024*1024,'affinity_CPUs':len(os.sched_getaffinity(0))},'elapsed_seconds':time.monotonic()-start,'actor_top_level_builder_collector_product_imports_or_live_calls':0,'actual_current_authority_created':False}
(B/'CHANGED-CONTROLS.json').write_bytes(m.encoded(out));print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
