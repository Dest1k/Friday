"""Finite source preparation only; never imports or executes copied consumers."""
from pathlib import Path
import ast, datetime, difflib, hashlib, json, os, shlex, time

os.umask(0o077)
B=Path(__file__).resolve().parent
OLD=Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-ROOT-MAINTENANCE-FRAME-20261111')
R2=Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-STARTUP-OBSERVER-R2-20261112')
PUB='frw-astra-native204-install-r2-20261112.service'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def write(name,data):
 p=B/name;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data if isinstance(data,bytes) else data.encode())
 return p
def ref(p):return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
start=time.monotonic()
write('START.json',enc({'assignment':'ASTRA-CORE204-FUTURE-FRAME-R2-PREPARE-20261112#1','accepted_at_moscow':'2026-11-12T03:51:06+03:00','source_preparation_started_at_moscow':datetime.datetime.now().astimezone().isoformat(),'start_monotonic':start,'scope':'SOURCE_ONLY_NO_EXECUTION_NO_CURRENT_AUTHORITY'}))
expected={'run_native204_once.py':'a8b50f0097763eb0a0c1546d01ad0c908be2bcd5770b6665d7ac7d86ee5a1e8d','root204_metadata.py':'c0c874096157de646cd50dea889dc8ae58616b35b5bcf6451b1c7fcc8bad9487','resume_native204_services.py':'19888c7483ca5f948fd73024e10489278c8bb0b44d28585881c75239111efaff','publication/build-layer-publication-request.py':'bb27b988a988929a8ce6197dd9d08b0a50914ecd9781e3076ab89cceface3287','publication/friday_v3_layer_publication.py':'c88d67818dc1195833a11ec8f9ba0235ba5a37759d3db20aba1ff92bc9560a32','admission-retained/observe-current-retained-units.py':'c719860c492f9ae2eb88c6267905d06aac338fec97f05f12bbd2c787e043d6d5'}
assert all(sha(OLD/n)==s for n,s in expected.items())
candidate=R2/'candidate/run_native204_once.py'
assert sha(candidate)=='f890c9b10c43620a214f33fec7a56525eb02cf5a5fbb0a8c7dec3351853d6bb1'
for n in ('publication/build-layer-publication-request.py','publication/friday_v3_layer_publication.py','admission-retained/observe-current-retained-units.py'):write(n,(OLD/n).read_bytes())
policy=json.loads((OLD/'ROOT-204-PUBLIC-ORIGIN-POLICY.json').read_bytes())
for row in policy['retained_executed_sources'].values():
 if row['path'].startswith(str(OLD)+'/publication/'):
  row['path']=str(B/'publication'/Path(row['path']).name)
write('ROOT-204-PUBLIC-ORIGIN-POLICY.json',enc(policy))
metadata=(OLD/'root204_metadata.py').read_text()
metadata=metadata.replace("'sha256': 'a2530b8108ccb48df42d256d238f52b9f43d0011deacfe05a20cc1ad23dea8b3'",repr('sha256')+': '+repr(sha(B/'ROOT-204-PUBLIC-ORIGIN-POLICY.json')))
write('root204_metadata.py',metadata)
actor=candidate.read_text().replace("PUB = 'frw-astra-native204-publication-20261111.service'",'PUB = '+repr(PUB))
recovery=(OLD/'resume_native204_services.py').read_text().replace("PUB = 'frw-astra-native204-publication-20261111.service'",'PUB = '+repr(PUB))
# The recovery status consumer must see the real home even from a clean parent.
needle="N = H / 'hermes-agent'\n"
assert recovery.count(needle)==1
recovery=recovery.replace(needle,needle+"os.environ.update(HERMES_HOME=str(H),\n    HERMES_GATEWAY_LOCK_DIR='/home/jericho/.local/state/hermes/gateway-locks',\n    GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')\n")
atree=ast.parse(actor);rtree=ast.parse(recovery)
terminal=next(n for n in atree.body if isinstance(n,ast.FunctionDef) and n.name=='publisher_terminal_proven')
oldterminal=next(n for n in rtree.body if isinstance(n,ast.FunctionDef) and n.name=='publisher_terminal_proven')
rlines=recovery.splitlines(keepends=True)
recovery=''.join(rlines[:oldterminal.lineno-1])+ast.get_source_segment(actor,terminal)+'\n'+''.join(rlines[oldterminal.end_lineno:])
# Retain an actual future status exit before its refusal; no output or secret is saved.
needle="                    if status.returncode == 3 and not was_verified:\n"
assert recovery.count(needle)==1
recovery=recovery.replace(needle,"                    phase['last_dashboard_status_returncode'] = status.returncode\n                    save()\n"+needle)
write('resume_native204_services.py',recovery)
actor=actor.replace(expected['root204_metadata.py'],sha(B/'root204_metadata.py')).replace(expected['resume_native204_services.py'],sha(B/'resume_native204_services.py'))
write('run_native204_once.py',actor)
for name in ('ROOT-204-FRESH-ADMISSION-TEMPLATE.json','ROOT-204-FRESH-READBACK-TEMPLATE.json','ROOT-204-SOURCE-ACCEPTANCE-TEMPLATE.json','ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION-TEMPLATE.json'):
 value=json.loads((OLD/name).read_bytes())
 def retarget(v):
  if isinstance(v,dict):
   out={k:retarget(x) for k,x in v.items()}
   if out.get('path')==str(B/'run_native204_once.py'):out['sha256']=sha(B/'run_native204_once.py')
   if out.get('path')==str(B/'resume_native204_services.py'):out['sha256']=sha(B/'resume_native204_services.py')
   return out
  if isinstance(v,list):return [retarget(x) for x in v]
  if isinstance(v,str) and v.startswith(str(OLD)+'/'):return str(B)+v[len(str(OLD)):]
  return v
 value=retarget(value)
 assert value['template_only_no_execution_grant'] is True
 write(name,enc(value))
commands=json.loads((OLD/'ROOT-FUTURE-COMMANDS.json').read_bytes())
commands['commands']={key:[str(B)+x[len(str(OLD)):] if x.startswith(str(OLD)+'/') else x for x in args] for key,args in commands['commands'].items()}
commands['environment']['HERMES_GATEWAY_LOCK_DIR']='/home/jericho/.local/state/hermes/gateway-locks'
commands['shell_renderings']={k:shlex.join(v) for k,v in commands['commands'].items()}
commands['order']='Root independently accepts exact frame and R2 observer qualification; reconcile old consumed launch and full source-tx absence; current203/CAS/resources/cancel/slot/readbacks; normal builder; real source acceptance/local-committed-main provenance (or actual published-remote); fresh readback; binder; current minimum-bank/profile revalidation; fresh final admission; future once actor. Conditional recovery stays within only this future journal original deadlines. No command was executed during preparation.'
commands['origin_url']='https://github.com/Dest1k/Friday'
commands['reference_main_not_current_proof']='99f10f54e5e2989a3ec9c88b002d1fb3cacf4e3a'
commands['request_identity']='No nonce/date/output path is inserted. Identical inputs produce same request hash; source transaction must be wholly absent, not merely lack intent. Root separately admits genuinely missing source install stage after reconciled old launch; old actor journal is never reset.'
commands['future_publisher_unit']=PUB
write('ROOT-FUTURE-COMMANDS.json',enc(commands))
for name,original in [('run_native204_once.py',candidate),('root204_metadata.py',OLD/'root204_metadata.py'),('resume_native204_services.py',OLD/'resume_native204_services.py'),('ROOT-204-PUBLIC-ORIGIN-POLICY.json',OLD/'ROOT-204-PUBLIC-ORIGIN-POLICY.json')]:
 write('diffs/'+name+'.diff',''.join(difflib.unified_diff(original.read_text().splitlines(keepends=True),(B/name).read_text().splitlines(keepends=True),fromfile=str(original),tofile=str(B/name))))
write('IMMUTABLE-BASIS.json',enc({'state':'SOURCE_AND_HISTORICAL_FACTS_ONLY_NOT_CURRENT_READBACK','old_source_files':{n:ref(OLD/n) for n in expected},'r2_source':ref(candidate),'old_service_closure':ref(Path('/home/jericho/.cache/FRW-ASTRA-V3-POSTPOWER-RECOVERY-20261111/CORE204-LOCAL-FIRST-EXECUTION-20261112/ROOT-FINAL-OLD203-SERVICE-CLOSURE.json')),'r2_independent_source_review':ref(Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-R2-INDEPENDENT-REVIEW-20261112/RESULT.json')),'r2_observer_only_harmless_qualification':ref(Path('/home/jericho/.cache/FRW-ASTRA-V3-POSTPOWER-RECOVERY-20261111/CORE204-R2-OBSERVER-REAL-HARMLESS-UNITS-20261112/RESULT.json')),'old_helper_status_failure':'Raw code not retained; original unknown remains. No guessed causal attribution in this packet. Future explicit environment and raw exit retention are prospective changes only.'}))
print(json.dumps({'state':'SOURCE_PREPARED_NOT_EXECUTED','bundle':str(B),'publisher':PUB,'source_files':len(expected),'elapsed_seconds':time.monotonic()-start}))
