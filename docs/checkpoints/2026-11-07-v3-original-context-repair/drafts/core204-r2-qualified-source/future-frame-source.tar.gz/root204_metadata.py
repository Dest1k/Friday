"""Pure metadata join for a later Root boundary; no collector, product import or grant.
Only CLI --validate-and-bind writes an exclusive own-bundle metadata record. It cannot
produce request/admission/qualification/source acceptance or call any live consumer.
Root supplies authentic readbacks; validation is not a kernel/runtime proof.
"""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,stat,time
B=Path(__file__).resolve().parent
H=Path('/home/jericho/jericho/Friday_rework/.runtime/friday-normal-both-workers-frw032')
S=Path('/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111')
P=Path('/home/jericho/.cache/FRW-SOL-V3-CORE203-FINAL-COMPOSITION-20261111/project487')
C=S/'project489'
LAYER='rtf-optional-footnote-reader-after-source203'
BEFORE_RECEIPT='9d8d1d954a59d5f944cb0b33c11cba3bba845cbb5d71088f335d68077c2a83c2'
PREVIOUS_INPUT='31178b28f928c937118d5c58df5aa15bb9fe23f748979cbdd9cb2f1456f513ad'
PREDECESSOR={'path':str(H/'preparation/ordinary-source-update-v45-1eab70363fcb0ef8/request.json'),'sha256':'1eab70363fcb0ef8886218006e8c59524230624d24815ea9b0aa6b6ef390d58c'}
ROOT198={'path':'/home/jericho/.cache/FRW-ASTRA-V3-DSH-COHERENT-ROOT-COMPOSITION-20261111/final-v1/fresh-source-request/REQUEST.json','sha256':'886c6ab5bc76a810b24004f7042ef7c1b5add1b78f04781fac9c96335e3bd448'}
# Prepared source evidence only: none of these pins is a final gate/result grant.
FIXED={'prepared_composition': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/M2.json', 'sha256': '243ba866698257d049431339c14384e3d67c4fb6d0df23dc0cc4a9742a58e42e'}, 'native_spec': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/FINAL-NATIVE-SPEC.json', 'sha256': 'c1326f41e874c4993ae34b1513e9b33fbfdceee4c72d8d7d0d33cafe829a535f'}, 'source_freeze': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/SOURCE-FREEZE-FINAL-R2.json', 'sha256': '3308603b01d73ccbef42ecef629be724e3dda5da2d543238a3f34f4a2266a1f2'}, 'prepared_root_recipe': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/ROOT-INTEGRATION-RECIPE-PREPARED-R2.json', 'sha256': '181ba3d988c583ae2c9a300bb1d2fa2104254ab0466fa7f0cc7a5a35ad3c57ef'}, 'pm_environment_basis': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/READONLY-PM-ENVIRONMENT-BASIS.json', 'sha256': '2ab5df26d6bd153ccc175e5813ad0fd769be377611b653fee486e3c3fab2062e'}, 'counterparts': {'path': '/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111/COUNTERPART-INVARIANTS.json', 'sha256': 'ec26ea2e96fa64d8e3f298999f3c59751678ed132ff892e3c68a228f7ed4bbad'}}
FINAL_GATE_LABELS=('operational-success','operational-rollback','public-success','public-rollback')
SNAPSHOT_TRUE_FIELDS=(
 'source_authority_verified','public_source_pins_verified','operational_source_pins_verified',
 'profile_routing_verified','process_environment_verified','ordinary_readonly_quiescent',
 'all_three_user_db_zero_leases','stop_cooldown_clear','sole_heavy_slot_clear',
 'no_current_maintenance','cancellation_clear','resources_sufficient',
 'all_profile_owned_work_quiescent','current_request_unconsumed','old_effects_not_replayed',
 'native_pm_selected_python_verified','product_services_healthy_infinite_lifetime',
 'unchanged_bank_profile_evidence_reusable','known_limits_retained')
class InvalidBinding(ValueError):pass
def require(value,reason):
 if not value:raise InvalidBinding(reason)
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def owned(path):
 p=Path(path);v=p.lstat()
 require(stat.S_ISREG(v.st_mode) and not p.is_symlink() and v.st_uid==os.getuid() and v.st_nlink==1,'owned_regular_singlelink_required:'+str(p))
 # Historical0664 is accepted under protected home after identity/hash validation.
 for parent in p.parents:
  if parent==Path('/'):break
  w=parent.lstat();require(stat.S_ISDIR(w.st_mode) and not parent.is_symlink(),'real_parent_required')
 return p

def reference(path):return {'path':str(path),'sha256':sha(owned(path))}
def readref(ref):
 require(type(ref) is dict and set(ref)=={'path','sha256'},'exact_reference_fields_required')
 p=owned(ref['path']);require(sha(p)==ref['sha256'],'reference_hash_changed:'+str(p));return json.loads(p.read_bytes())
def fresh(value,now,reason):
 try:
  instant=datetime.datetime.fromisoformat(value);require(instant.utcoffset() is not None,'timezone_required')
  age=now-instant.timestamp();require(0<=age<=300,reason)
 except (ValueError,TypeError,OverflowError) as e:raise InvalidBinding(reason) from e

# Published target204 is immutable; current publication head is a separate fact.
ORIGIN_POLICY = {'path': str(B/'ROOT-204-PUBLIC-ORIGIN-POLICY.json'),
                 'sha256': 'e2f465c5e99a956b0e2c5f723d73f728067309d8ea22453f756949c1afb916d9'}

def origin_git(repository, *args, input=None):
 import subprocess
 # Never use replacement objects, optional index writes or a network operation here.
 env=dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')
 return subprocess.run(['/usr/bin/git','--no-optional-locks','--no-replace-objects',
                        '-C',str(repository),*args], input=input,
                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                       timeout=20,check=True,env=env).stdout

def git_oid(kind, raw):
 return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def origin_tree(repository, commit):
 raw=origin_git(repository,'ls-tree','-rz','--full-tree',commit)
 rows={}
 for record in raw.split(b'\0'):
  if not record:continue
  header,name=record.split(b'\t',1);mode,kind,oid=header.decode().split()
  name=name.decode('utf-8');require(name not in rows,'duplicate_git_path')
  rows[name]=(mode,kind,oid)
 return rows

def origin_blobs(repository, tree, expected, modes=None):
 names=sorted(expected)
 modes={name:'100644' for name in names} if modes is None else modes
 require(set(modes)==set(expected) and all(mode in ('100644','100755') for mode in modes.values()),'exact_regular_git_modes_required')
 require(all(name in tree and tree[name][:2]==(modes[name],'blob') for name in names),
         'exact_regular_published_blobs_required')
 oids=[tree[name][2] for name in names]
 raw=origin_git(repository,'cat-file','--batch',input=('\n'.join(oids)+'\n').encode())
 offset=0
 for name,oid in zip(names,oids):
  end=raw.index(b'\n',offset);header=raw[offset:end].decode().split();offset=end+1
  require(len(header)==3 and header[:2]==[oid,'blob'],'exact_git_blob_header_required')
  size=int(header[2]);body=raw[offset:offset+size];offset+=size
  require(raw[offset:offset+1]==b'\n' and len(body)==size,'complete_git_blob_required');offset+=1
  require(git_oid('blob',body)==oid,'git_blob_object_identity_changed')
  require(hashlib.sha256(body).hexdigest()==expected[name],'published_blob_changed:'+name)
 require(offset==len(raw),'unexpected_git_batch_tail')

def source_origin(expected_head, fresh_origin, *, repository=None, provenance_mode='published-remote'):
 """Exact local objects/bytes plus an explicitly selected Root provenance mode.

 published-remote requires real fresh remote output from the Root boundary.
 local-committed-main makes no publication claim and requires origin=None.
 This function never calls a network or grants installed/runtime acceptance.
 """
 repository=Path(repository) if repository is not None else H.parents[1]
 policy=readref(ORIGIN_POLICY)
 require(policy['schema']=='frw.root204.published-prefix-origin-policy.v1','origin_policy_schema')
 require(len(expected_head)==40 and all(c in '0123456789abcdef' for c in expected_head),'bound_current_head_required')
 head=origin_git(repository,'rev-parse','HEAD').decode().strip()
 require(provenance_mode in ('published-remote','local-committed-main'),'explicit_provenance_mode_required')
 require(head==expected_head,'bound_current_head_required')
 if provenance_mode=='published-remote':
  require(head==fresh_origin,'fresh_current_head_origin_required')
 else:
  require(fresh_origin is None,'local_mode_has_no_remote_observation')
  require(origin_git(repository,'symbolic-ref','-q','HEAD').strip()==b'refs/heads/main','local_committed_main_branch_required')
  require(origin_git(repository,'rev-parse','refs/heads/main').decode().strip()==head,'local_main_head_mismatch')
  require(not origin_git(repository,'for-each-ref','--format=%(refname)','refs/replace/').strip(),'replacement_objects_refused')
 raw_head=origin_git(repository,'cat-file','commit',head)
 require(git_oid('commit',raw_head)==head,'current_commit_object_identity_changed')
 require(origin_git(repository,'rev-parse','--is-shallow-repository').strip()==b'false','full_local_ancestry_required')
 graft=Path(origin_git(repository,'rev-parse','--path-format=absolute','--git-path','info/grafts').decode().strip())
 require(not os.path.lexists(graft),'grafted_ancestry_refused')
 snapshot=policy['published_snapshot']
 raw=origin_git(repository,'cat-file','commit',snapshot)
 require(git_oid('commit',raw)==snapshot,'snapshot_commit_object_identity_changed')
 origin_git(repository,'merge-base','--is-ancestor',snapshot,head)
 public=readref(policy['public_input'])['project_files']
 private=readref(policy['private_input'])['project_files']
 counterpart=readref(policy['counterparts'])
 require(set(public)==set(private) and len(public)==489,'exact204_inventory_required')
 differences=sorted(name for name in public if public[name]!=private[name])
 require(differences==counterpart['retained_private_difference_names'] and len(differences)==28,
         'exact28_private_public_differences_required')
 require(counterpart['operational_input']=={**policy['private_input'],'bytes':73363} and
         counterpart['public_input']=={**policy['public_input'],'bytes':73363},'exact204_counterpart_inputs_required')
 oldtree=origin_tree(repository,snapshot)
 origin_blobs(repository,oldtree,public)
 origin_blobs(repository,oldtree,policy['snapshot_guards'],policy['snapshot_guard_modes'])
 for name,digest in private.items():
  require(sha(owned(C/name))==digest,'private204_source_changed:'+name)
 for name,row in policy['retained_executed_sources'].items():
  require(reference(row['path'])=={k:row[k] for k in ('path','sha256')},'executed204_source_changed:'+name)
  require(row['sha256']==policy['snapshot_guards'][name],'executed204_published_join_changed')
 current=policy['reviewed_current_files']
 newtree=origin_tree(repository,head)
 origin_blobs(repository,newtree,current,policy['reviewed_current_modes'])
 for name,digest in current.items():
  require(sha(owned(repository/name))==digest,'current_public_working_drift:'+name)
 # Recheck mutable working HEAD after all local object/source reads.
 require(origin_git(repository,'rev-parse','HEAD').decode().strip()==head,'current_head_changed_during_origin_check')
 if provenance_mode=='local-committed-main':
  require(origin_git(repository,'symbolic-ref','-q','HEAD').strip()==b'refs/heads/main' and
          origin_git(repository,'rev-parse','refs/heads/main').decode().strip()==head,'local_main_changed_during_origin_check')
 return {'schema':'frw.root204.published-prefix-origin-proof.v1',
         'policy':dict(ORIGIN_POLICY),'published_snapshot':snapshot,
         'current_head':head,'fresh_origin_main':fresh_origin,
         'provenance_mode':provenance_mode,
         'remote_publication':'DEFERRED_NOT_VERIFIED' if provenance_mode=='local-committed-main' else 'FRESH_REMOTE_MAIN_VERIFIED',
         'public_project_files':489,'private_difference_count':28,
         'snapshot_guard_count':len(policy['snapshot_guards']),
         'reviewed_current_file_count':len(current),
         'target_input_sha256':policy['private_input']['sha256'],
         'target_receipt_sha256':policy['target_receipt_sha256']}

def validate_snapshot_origin(acceptance,snapshot):
 policy=readref(ORIGIN_POLICY)
 require(acceptance['public_main_sha']==policy['published_snapshot'],'accepted204_published_snapshot_required')
 proof=source_origin(snapshot['head'],snapshot['origin_main'],provenance_mode=snapshot['provenance_mode'])
 require(snapshot['source_origin']==proof,'exact_current_origin_proof_required')
 return proof


def project_source_pins(request):
 previous=readref(request['previous_input']);current=readref(request['current_input'])
 require(request['previous_input']['sha256']==PREVIOUS_INPUT,'real_source203_input_required')
 require((len(previous['project_files']),len(current['project_files']))==(487,489),'project487_to489_required')
 for root,value in [(P,previous),(C,current)]:
  for name,digest in value['project_files'].items():require(sha(owned(root/name))==digest,'project_inventory_changed:'+name)
 expected={str(C/'scripts/friday_ordinary_install.py'):current['project_files']['scripts/friday_ordinary_install.py']}
 require(request['project_file_updates']==['scripts/friday_ordinary_install.py'],'exact_private_helper_update_required')
 require(request['plugin_set']==request['plugin_additions']==request['staged_files']==[],'no_plugin_or_worker_staging_required')
 require(request['project_inventory']==current['project_files'],'request_inventory_changed')
 require(request['project_inventory_sha256']==hashlib.sha256(encoded(current['project_files'])).hexdigest(),'inventory_digest_changed')
 require(request['current_input']==request['candidate_input'],'candidate_input_changed')
 return previous,current

def project_receipt(before,spec,current):
 result=copy.deepcopy(before)
 result['layers'].append({'manifest':spec['manifest_rel'],'manifest_sha256':spec['manifest_sha256'],'patch_sha256':spec['patch_sha256']})
 lock=current['sources_lock'];result['sources_lock_sha256']=lock['sha256'] if isinstance(lock,dict) else sha(lock)
 for row in spec['native_files']:
  value=dict(result['files'].get(row['path'],{}));value.update(sha256=row['sha256'],bytes=row['bytes'],mode='100644');result['files'][row['path']]=value
 return result

def validate_source_request(request):
 require(set(request)==set(('schema seconds home candidate_project layer_names marker source_receipt stamp configuration profile launcher native_unit previous_input current_input predecessor_request predecessor_current_input_sha256 predecessor_receipt_sha256 target_receipt candidate_input project_inventory project_inventory_sha256 plugin_set plugin_additions project_file_updates staged_files layer_manifest_updates installed_layers installed_files transaction_history current_source_successor').split()),'exact_builder_fields_no_test_injection_required')
 canonical={'marker':H/'FRIDAY-INSTALL.json','source_receipt':H/'hermes-agent.source.json','target_receipt':H/'hermes-agent.source.json','stamp':H/'hermes-agent/install-stamp.json','configuration':H/'config.yaml','profile':H/'FRIDAY-PROFILE.json','launcher':H/'hermes-agent/.hermes/bin/hermes','native_unit':Path('/home/jericho/.config/systemd/user/hermes-gateway-1b7e7667.service'),'previous_input':P.parent/'INPUT-SOURCE203.json','current_input':S/'INPUT-SOURCE204.json','candidate_input':S/'INPUT-SOURCE204.json','predecessor_request':H/'preparation/ordinary-source-update-successor-afb9863d58ee319d96e00e313a8cc495c6cb883f75430e7adcbb24c80ef5de00/request.json'}
 require(all(request[key]['path']==str(path) for key,path in canonical.items()),'canonical_request_paths_required')
 require(request['current_input']=={'path':str(S/'INPUT-SOURCE204.json'),'sha256':'cb35f5a9cdac806d95e51c70038944a29f4d1abf28ee74caaf2e9593d79d6677'},'exact_final204_input_required')
 require(request['previous_input']=={'path':str(P.parent/'INPUT-SOURCE203.json'),'sha256':PREVIOUS_INPUT},'exact_final203_input_required')
 require(request['target_receipt']==request['source_receipt'],'one_current_receipt_required')
 require(request['predecessor_request']['sha256']=='afb9863d58ee319d96e00e313a8cc495c6cb883f75430e7adcbb24c80ef5de00' and request['predecessor_current_input_sha256']=='3948650d65fa78b48aa3bc838d4948815af2b75e4db5fffe29886c2707c7f93c' and request['predecessor_receipt_sha256']=='2c0eea5c2647172a0d059c2993c898b401c7d808bbcc85ee766d51aae7c0e51d','genuine_historical_root_predecessor_required')
 require(request['schema']=='friday.ordinary-telegram-source-update.v46','explicit_v46_required')
 require(request['home']==str(H) and request['candidate_project']==str(C),'exact_home_candidate_required')
 require(request['seconds']==600 and type(request['seconds']) is int,'forward600_required')
 require(request['layer_names']==[LAYER],'one_explicit_sixth_layer_required')
 require(request['installed_layers']==203 and request['installed_files']==17891,'true203_required')
 require(request['current_source_successor']=={'schema':'friday.current-source-native-successor.v6','root_project_update':ROOT198,'previous_native_update':PREDECESSOR},'genuine_root198_to203_chain_required')
 readref(ROOT198);readref(PREDECESSOR)
 for key in ('marker','source_receipt','stamp','configuration','profile','launcher','native_unit','previous_input','current_input','predecessor_request','target_receipt','candidate_input'):
  # Some runtime pins (launcher/config/unit) are not JSON; only verify bytes/identity.
  ref=request[key];require(reference(ref['path'])==ref,'request_pin_changed:'+key)
 require(request['source_receipt']['sha256']==BEFORE_RECEIPT,'genuine_current203_receipt_required')
 previous,current=project_source_pins(request)
 spec=readref(FIXED['native_spec']);before=readref(request['source_receipt'])
 require((len(before['layers']),len(before['files']),before['source_file_count'])==(203,17891,17730),'real203_inventory_required')
 require(len(spec['native_files'])==1 and sum(row['new_file'] for row in spec['native_files'])==0,'onepath_no_native_absent_required')
 require({row['path'] for row in spec['native_files']}=={'tools/scoped_rtf.py'},'exact_rtf_path_required')
 require(request['layer_manifest_updates']==[spec['manifest_rel']],'only_new_pair_required')
 for row in spec['native_files']:
  path=H/'hermes-agent'/row['path']
  require(not os.path.lexists(path) if row['new_file'] else reference(path)['sha256']==row['before_sha256'],'native_preimage_changed:'+row['path'])
  require(sha(owned(Path(spec['native_source_directory'])/row['path']))==row['sha256'],'native_afterimage_changed:'+row['path'])
 for role in ['manifest','patch']:require(reference(spec[role]['path'])=={k:spec[role][k] for k in ('path','sha256')},'pair_changed')
 projected=project_receipt(before,spec,current)
 require((len(projected['layers']),len(projected['files']))==(204,17891),'projection_count_wrong')
 proposed=spec['private_proposed_receipt'];require(sha(proposed['path'])==proposed['sha256'],'proposed_receipt_changed')
 require(hashlib.sha256(encoded(projected)).hexdigest()==proposed['sha256'],'exact204_projection_required')
 require(projected['layers'][:-1]==before['layers'],'exact203_prefix_required')
 native_paths={row['path'] for row in spec['native_files']}
 untouched={name:row for name,row in before['files'].items() if name not in native_paths}
 require(len(untouched)==17890 and {name:row for name,row in projected['files'].items() if name not in native_paths}==untouched,'all17890_untouched_native_rows_required')
 targets={str(H/'hermes-agent'/row['path']):{'before_sha256':row['before_sha256'],'after_sha256':row['sha256'],'native_new':row['new_file']} for row in spec['native_files']}
 for name in request['project_file_updates']+[spec['manifest_rel'],spec['patch_rel']]:
  path=H/name;targets[str(path)]={'before_sha256':previous['project_files'].get(name),'after_sha256':current['project_files'][name],'native_new':False}
 for key in ['marker','source_receipt','stamp']:targets[request[key]['path']]={'before_sha256':request[key]['sha256'],'metadata':True}
 require(len(targets)==7,'exact_seven_targets_required')
 for path,pin in targets.items():
  require(not os.path.lexists(path) if pin['before_sha256'] is None else reference(path)['sha256']==pin['before_sha256'],'selected_target_preimage_changed:'+path)
 return {'expected_receipt_sha256':hashlib.sha256(encoded(projected)).hexdigest(),'selected_target_count':7,'selected_targets':targets,'before_layers':203,'after_layers':204,'native_files_after':17891,'project_files_after':489,'current_input':request['current_input'],'previous_input':request['previous_input'],'native_spec':FIXED['native_spec']}

def validate_join(request,acceptance,snapshot,*,now,boot_id):
 for ref in FIXED.values():readref(ref)
 result=validate_source_request(request)
 require(acceptance['schema']=='frw.root.native204-source-acceptance.v1' and acceptance['state']=='ROOT_ACCEPTED_EXACT204_SOURCE_OFFLINE_AND_RETAINED_RICH_REVIEW_NOT_RUNTIME','root_source_acceptance_required')
 require(acceptance['accepted'] is True and acceptance['execution_grant'] is False and acceptance['template_only_no_execution_grant'] is False,'source_acceptance_only')
 require(acceptance['source_pins']==FIXED,'exact_prepared_source_pins_required')
 require(acceptance['final_source_result']['path']==str(S/'RESULT.json'),'real_final204_result_path_required')
 require(len(acceptance['final_source_result']['sha256'])==64 and all(c in '0123456789abcdef' for c in acceptance['final_source_result']['sha256']),'bound_final_result_hash_required')
 readref(acceptance['final_source_result'])
 require(acceptance['all_four_current_source_gates_accepted'] is True and acceptance['gate_retry_history_preserved'] is True,'Root_final_four_gates_acceptance_required')
 require(tuple(row['label'] for row in acceptance['four_gate_evidence'])==FINAL_GATE_LABELS,'exact_four_gate_labels_required')
 for row in acceptance['four_gate_evidence']:readref(row['evidence'])
 for ref in acceptance['independent_review_evidence']+acceptance['newapp_review_evidence']:readref(ref)
 require(acceptance['independent_review_evidence'] and acceptance['newapp_review_evidence'],'actual_review_evidence_required')
 require(snapshot['schema']=='frw.root.native204-fresh-readback.v1' and snapshot['state']=='ROOT_CURRENT_READBACK_NOT_EXECUTION_GRANT','fresh_root_readback_required')
 require(snapshot['template_only_no_execution_grant'] is False,'actual_readback_not_template_required')
 require(snapshot['boot_id']==boot_id,'current_boot_required');fresh(snapshot['observed_at_moscow'],now,'fresh_readback_required')
 require(all(snapshot['checks'][key] is True for key in SNAPSHOT_TRUE_FIELDS),'all_current_boundary_checks_required')
 origin_proof=validate_snapshot_origin(acceptance,snapshot)
 require(len(snapshot['head'])==40 and all(c in '0123456789abcdef' for c in snapshot['head']),'real_git_sha_required')
 require(snapshot['installed_receipt_sha256']==BEFORE_RECEIPT and snapshot['installed_input_sha256']==PREVIOUS_INPUT,'current_source203_pins_required')
 for service in ('gateway','dashboard'):
  identity=snapshot['services'][service];require(identity['boot_id']==boot_id and type(identity['pid']) is int and identity['pid']>0 and type(identity['birth_ticks']) is int and identity['birth_ticks']>0,'fresh_process_identity_required')
  require(len(identity['invocation_id'])==32 and identity['cgroup'].startswith('/user.slice/') and identity['enabled_active'] is True and identity['runtime_max']=='infinity','healthy_permanent_service_required')
 require(snapshot['evidence'],'fresh_actual_readback_evidence_required')
 for ref in snapshot['evidence']:readref(ref)
 require(snapshot['remaining_limits']=={'native_canonical_unknown':3,'structural_unresolved':45,'R104_semantic_fail':True,'default_workers_ready_accepted':False,'DSH_A0_deferred':True},'known_limits_must_remain')
 result.update(source_origin=origin_proof,fresh_root_services=copy.deepcopy(snapshot['services']),state='PURE_METADATA_BOUND_NOT_ADMISSION',source_acceptance={'path':str(B/'ROOT-204-SOURCE-ACCEPTANCE.json'),'sha256':hashlib.sha256(encoded(acceptance)).hexdigest()},snapshot_boot_id=boot_id,operation_seconds=1800,forward_seconds=600,external_rollback_seconds=180,publisher_terminal_cleanup_seconds=30,publisher_unit_seconds=810,publisher_client_seconds=840)
 return result

def load_actor_binding(bundle):
 require(Path(bundle).resolve()==B,'exact_bundle_required')
 request=readref(reference(B/'ROOT-FRESH-REQUEST.json'));acceptance=readref(reference(B/'ROOT-204-SOURCE-ACCEPTANCE.json'))
 snapshot=readref(reference(B/'ROOT-204-FRESH-READBACK.json'))
 value=validate_join(request,acceptance,snapshot,now=time.time(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
 saved=readref(reference(B/'ROOT-204-BOUND-INPUTS.json'))
 require(saved['binding']==value,'bound_input_join_changed')
 for key in ['request','source_acceptance','fresh_readback']:
  name={'request':'ROOT-FRESH-REQUEST.json','source_acceptance':'ROOT-204-SOURCE-ACCEPTANCE.json','fresh_readback':'ROOT-204-FRESH-READBACK.json'}[key]
  require(saved[key]==reference(B/name),'saved_input_ref_changed')
 return value

def main():
 p=argparse.ArgumentParser();p.add_argument('--validate-and-bind',action='store_true',required=True);args=p.parse_args()
 require(__debug__ and sys_flags_safe(),'isolated_nonoptimized_no_bytecode_required')
 request=readref(reference(B/'ROOT-FRESH-REQUEST.json'));acceptance=readref(reference(B/'ROOT-204-SOURCE-ACCEPTANCE.json'));snapshot=readref(reference(B/'ROOT-204-FRESH-READBACK.json'))
 value=validate_join(request,acceptance,snapshot,now=time.time(),boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())
 payload={'binding':value,**{key:reference(B/name) for key,name in [('request','ROOT-FRESH-REQUEST.json'),('source_acceptance','ROOT-204-SOURCE-ACCEPTANCE.json'),('fresh_readback','ROOT-204-FRESH-READBACK.json')]}}
 destination=B/'ROOT-204-BOUND-INPUTS.json';fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as stream:stream.write(encoded(payload));stream.flush();os.fsync(stream.fileno())
 print(json.dumps({'state':value['state'],'bound_inputs':reference(destination),'execution_grant':False}))
def sys_flags_safe():
 import sys
 return bool(sys.flags.isolated and sys.dont_write_bytecode)
if __name__=='__main__':main()
