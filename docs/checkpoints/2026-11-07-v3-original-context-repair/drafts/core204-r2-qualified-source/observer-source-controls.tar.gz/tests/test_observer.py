"""Finite source-only controls: execute extracted actor functions, never actor top-level.

The filesystem represents /proc and the historical cgroup in our private temp
tree. No system manager, real publisher, live PID, product file, or network is used.
"""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import tempfile
import time
import types
import unittest

os.umask(0o077)
START = time.monotonic()
signal.alarm(90)
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024,) * 2)
allowed = sorted(os.sched_getaffinity(0))[:2]
os.sched_setaffinity(0, allowed)
B = Path(__file__).resolve().parents[1]
PUB = 'owned-test.service'
GROUP = '/user.slice/user-1000.slice/user@1000.service/app.slice/' + PUB
INVOCATION = 'a' * 32
DESCRIPTION = 'Root-owned-exact-nonce'
FUNCTIONS = {'remaining', 'closed', 'publisher_cgroup_empty',
             'remember_publisher_identity', 'publisher_process_closed',
             'publisher_terminal_proven', 'close_owned_publisher',
             'run_owned_publisher'}


def snapshot(**changes):
    value = dict(Id=PUB, Description=DESCRIPTION, LoadState='loaded',
                 ActiveState='inactive', SubState='dead', MainPID='0',
                 ControlPID='0', ControlGroup='', InvocationID='',
                 Result='success', ExecMainStatus='0')
    value.update(changes)
    return value


class Harness:
    def __init__(self, source, *, binding=True, terminal=None, code=2,
                 polls=None, wait_timeout=False, process_birth=None,
                 populated=False, group_procs='', group_exists=True):
        self.temp = tempfile.TemporaryDirectory(dir=B / 'tests', prefix='state-')
        self.root = Path(self.temp.name)
        self.clock = 100.0
        self.calls = []
        self.saves = []
        self.current = snapshot() if terminal is None else terminal
        self.service_sequence = []
        self.wait_timeout = wait_timeout
        self.wait_timeout_value = None
        self.group_absent = True
        self.polls = list([None] if polls is None else polls)
        self.code = code
        self.reap_calls = 0
        self.spawn_calls = 0
        self.j = {'publisher_owned_description': DESCRIPTION}
        if binding:
            self.j.update(publisher_invocation_id=INVOCATION,
                          publisher_cgroup=GROUP,
                          publisher_process_identity={'pid': 777124, 'birth_ticks': 42})
        self.write_stat(777123, 41)
        if process_birth is not None:
            self.write_stat(777124, process_birth)
        if group_exists:
            self.write('sys/fs/cgroup' + GROUP + '/cgroup.events',
                       'populated ' + str(int(populated)) + '\nfrozen 0\n')
            self.write('sys/fs/cgroup' + GROUP + '/cgroup.procs', group_procs)
        self.child = types.SimpleNamespace(pid=777123, returncode=None,
                                           poll=self.poll, wait=self.wait)
        self.ns = dict(Path=self.path, j=self.j, PUB=PUB,
                       save=lambda: self.saves.append(copy.deepcopy(self.j)),
                       time=types.SimpleNamespace(monotonic=lambda: self.clock,
                                                  sleep=self.sleep),
                       subprocess=types.SimpleNamespace(
                           Popen=self.popen, CompletedProcess=subprocess.CompletedProcess,
                           TimeoutExpired=subprocess.TimeoutExpired),
                       service=self.service, command=self.command,
                       event=self.event, StopUnconfirmed=type('StopUnconfirmed', (RuntimeError,), {}),
                       reap_exact_owned_local_group=self.reap,
                       local_group_absent=lambda child: self.group_absent)
        tree = ast.parse(Path(source).read_text())
        chosen = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in FUNCTIONS]
        assert {n.name for n in chosen} == FUNCTIONS
        exec(compile(ast.Module(body=chosen, type_ignores=[]), str(source), 'exec'), self.ns)

    def write(self, name, text):
        target = self.root / name
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        target.write_text(text)

    def write_stat(self, pid, birth):
        tail = ['S'] + ['0'] * 19
        tail[19] = str(birth)
        self.write('proc/' + str(pid) + '/stat', str(pid) + ' (harmless) ' + ' '.join(tail))

    def path(self, value):
        text = str(value)
        if text == '/proc' or text.startswith('/proc/') or text == '/sys/fs/cgroup' or text.startswith('/sys/fs/cgroup/'):
            return self.root / text.lstrip('/')
        return Path(value)

    def sleep(self, seconds):
        assert seconds >= 0
        self.clock += seconds

    def poll(self):
        if self.child.returncode is None and self.polls:
            self.child.returncode = self.polls.pop(0)
        return self.child.returncode

    def wait(self, *, timeout):
        self.wait_timeout_value = timeout
        if self.wait_timeout:
            raise subprocess.TimeoutExpired(['systemd-run-simulated'], timeout)
        if self.child.returncode is None:
            self.child.returncode = self.code
        return self.child.returncode

    def popen(self, args, **kwargs):
        self.spawn_calls += 1
        self.calls.append(('popen', list(args), kwargs))
        return self.child

    def service(self, name=PUB, *, deadline=None):
        self.calls.append(('service', name, deadline))
        if self.service_sequence:
            item = self.service_sequence.pop(0)
            if callable(item):
                item = item()
            return copy.deepcopy(item)
        return copy.deepcopy(self.current)

    def command(self, args, **kwargs):
        self.calls.append(('command', args, kwargs))
        return types.SimpleNamespace(returncode=0)

    def event(self, name, **kwargs):
        self.calls.append(('event', name, kwargs))

    def reap(self, child, identity, flag):
        self.reap_calls += 1
        self.calls.append(('reap', identity, flag))
        if child.returncode is None:
            child.returncode = -9  # Explicitly cleanup-generated, never publication exit.

    def terminal(self, deadline=140):
        return self.ns['publisher_terminal_proven'](deadline=deadline)

    def run(self, deadline=140):
        return self.ns['run_owned_publisher'](['systemd-run-simulated'],
                                             stdout=None, stderr=None,
                                             client_deadline=deadline)

    def close(self, deadline=150):
        return self.ns['close_owned_publisher'](deadline)

    def cleanup(self):
        self.temp.cleanup()


class ObserverControls(unittest.TestCase):
    actor_number = 204

    def harness(self, *, before=False, **kwargs):
        location = B / ('before' if before else 'candidate') / ('run_native' + str(self.actor_number) + '_once.py')
        value = Harness(location, **kwargs)
        self.addCleanup(value.cleanup)
        return value

    def test_baseline_reproduces_empty_invocation_failure(self):
        h = self.harness(before=True, binding=False)
        with self.assertRaises(AssertionError):
            h.run()
        self.assertEqual(h.spawn_calls, 1)
        self.assertEqual(h.reap_calls, 1)

    def test_bound_collected_terminal_passes_and_retains_actual_client_codes(self):
        for code in [0, 2, 3, 17, -15]:
            with self.subTest(code=code):
                h = self.harness(code=code)
                r = h.run(deadline=140)
                self.assertEqual(r.returncode, code)
                self.assertEqual(h.j['publisher_client_returncode'], code)
                self.assertEqual(h.wait_timeout_value, 40)
                self.assertEqual(h.reap_calls, 0)
                self.assertEqual(h.spawn_calls, 1)
                self.assertEqual([x[2] for x in h.calls if x[0] == 'service'], [140, 140])

    def test_same_invocation_closed_and_not_found_pass(self):
        for u in [snapshot(InvocationID=INVOCATION),
                  snapshot(LoadState='not-found', Description=PUB)]:
            h = self.harness(terminal=u)
            self.assertEqual(h.terminal(), u)

    def test_each_missing_prior_binding_fails_for_empty_and_not_found(self):
        for key in ['publisher_invocation_id', 'publisher_cgroup', 'publisher_process_identity']:
            for load in ['loaded', 'not-found']:
                with self.subTest(key=key, load=load):
                    h = self.harness(terminal=snapshot(LoadState=load))
                    del h.j[key]
                    with self.assertRaisesRegex(AssertionError, 'owned_publisher_exact_binding_missing'):
                        h.terminal()

    def test_name_nonce_and_invocation_conflicts_fail(self):
        for change in [dict(Description='foreign-nonce'),
                       dict(InvocationID='b' * 32), dict(InvocationID='bad')]:
            h = self.harness(terminal=snapshot(**change))
            with self.assertRaises(AssertionError):
                h.terminal()

    def test_empty_invocation_never_accepts_active_or_unclosed_unit(self):
        for change in [dict(ActiveState='active'), dict(ActiveState='activating'),
                       dict(MainPID='777124'), dict(ControlPID='777125'),
                       dict(ControlGroup=GROUP)]:
            h = self.harness(terminal=snapshot(**change))
            with self.assertRaises(AssertionError):
                h.terminal()

    def test_pinned_cgroup_and_process_both_have_to_cease(self):
        for params in [dict(populated=True), dict(group_procs='777999\n'),
                       dict(process_birth=42)]:
            h = self.harness(**params)
            with self.assertRaisesRegex(AssertionError, 'owned_publisher_scope_not_closed'):
                h.terminal()

    def test_absent_cgroup_and_reused_pid_prove_original_ceased(self):
        for params in [dict(group_exists=False), dict(process_birth=43)]:
            h = self.harness(**params)
            self.assertEqual(h.terminal()['InvocationID'], '')

    def test_foreign_historical_cgroup_path_is_rejected(self):
        for group in ['/system.slice/' + PUB, GROUP + '/child', '/user.slice/../' + PUB]:
            h = self.harness()
            h.j['publisher_cgroup'] = group
            with self.assertRaises(AssertionError):
                h.terminal()

    def test_identity_acquisition_guard_remains_exact(self):
        h = self.harness(binding=False, process_birth=42)
        h.write('proc/777124/cgroup', '0::' + GROUP + '\n')
        active = snapshot(ActiveState='active', MainPID='777124',
                          InvocationID=INVOCATION, ControlGroup=GROUP)
        h.ns['remember_publisher_identity'](active)
        self.assertEqual(h.j['publisher_process_identity'], {'pid': 777124, 'birth_ticks': 42})
        self.assertEqual(h.j['publisher_invocation_id'], INVOCATION)
        self.assertEqual(h.j['publisher_cgroup'], GROUP)
        for change in [dict(InvocationID=''), dict(InvocationID='b' * 32),
                       dict(Description='foreign')]:
            with self.assertRaises(AssertionError):
                h.ns['remember_publisher_identity'](dict(active, **change))

    def test_closing_collected_terminal_never_requests_stop_or_kill(self):
        h = self.harness()
        h.close(deadline=150)
        self.assertTrue(h.j['publisher_closed_before_parent_custody_release'])
        self.assertEqual(h.j['publisher_terminal_unit'], h.current)
        self.assertFalse(any(x[0] == 'command' for x in h.calls))
        self.assertEqual([x[2] for x in h.calls if x[0] == 'service'], [150])

    def test_live_exact_unit_still_uses_existing_bounded_stop_path(self):
        active = snapshot(ActiveState='active', MainPID='777124',
                          InvocationID=INVOCATION, ControlGroup=GROUP)
        h = self.harness(process_birth=42)
        h.write('proc/777124/cgroup', '0::' + GROUP + '\n')
        def cease():
            (h.root / 'proc/777124/stat').unlink()
            return snapshot()
        h.service_sequence = [active, active, cease]
        h.close(deadline=150)
        commands = [x for x in h.calls if x[0] == 'command']
        self.assertEqual(len(commands), 1)
        self.assertEqual(commands[0][1], ['systemctl', '--user', 'stop', '--no-block', PUB])
        self.assertEqual(commands[0][2]['deadline'], 130)
        self.assertTrue(h.j['publisher_closed_before_parent_custody_release'])

    def test_foreign_unit_never_gets_stop_authority(self):
        for u in [snapshot(Description='foreign'), snapshot(InvocationID='b' * 32),
                  snapshot(LoadState='not-found', Description=PUB)]:
            h = self.harness(terminal=u, binding=False)
            with self.assertRaises(AssertionError):
                h.close()
            self.assertFalse(any(x[0] == 'command' for x in h.calls))

    def test_timeout_cleanup_does_not_invent_publication_exit(self):
        h = self.harness(wait_timeout=True)
        with self.assertRaises(subprocess.TimeoutExpired):
            h.run()
        self.assertIsNone(h.j['publisher_client_returncode'])
        self.assertEqual(h.child.returncode, -9)
        self.assertEqual(h.reap_calls, 1)
        self.assertEqual(h.spawn_calls, 1)

    def test_already_exited_client_is_retained_even_when_observer_refuses(self):
        for code in [0, 2, 17, -15]:
            h = self.harness(binding=False, polls=[None, code])
            with self.assertRaises(AssertionError):
                h.run()
            self.assertEqual(h.j['publisher_client_returncode'], code)
            self.assertEqual(h.spawn_calls, 1)

    def test_exited_before_binding_is_error_with_actual_client_code(self):
        h = self.harness(binding=False, polls=[2])
        with self.assertRaisesRegex(AssertionError, 'publisher_finished_without_exact_binding'):
            h.run()
        self.assertEqual(h.j['publisher_client_returncode'], 2)

    def test_result_fields_do_not_supply_client_exit(self):
        h = self.harness(code=17, terminal=snapshot(Result='success', ExecMainStatus='0'))
        self.assertEqual(h.run().returncode, 17)
        self.assertEqual(h.j['publisher_client_returncode'], 17)

    def test_deadline_expiry_preserves_exception_and_unknown(self):
        h = self.harness()
        with self.assertRaisesRegex(RuntimeError, 'original_maintenance_budget_exhausted'):
            h.run(deadline=100)
        self.assertIsNone(h.j['publisher_client_returncode'])
        self.assertIsNone(h.wait_timeout_value)
        self.assertEqual(h.reap_calls, 1)

    def test_reaped_client_descendant_group_still_requires_reconciliation(self):
        h = self.harness(code=2)
        h.group_absent = False
        with self.assertRaisesRegex(h.ns['StopUnconfirmed'], 'reaped_publisher_client_leader_group_requires_Root_reconciliation'):
            h.run()
        self.assertTrue(h.j['publisher_client_cleanup_unconfirmed'])
        self.assertEqual(h.j['publisher_client_returncode'], 2)


    def prepared_unbound(self, **kwargs):
        h = self.harness(binding=False, process_birth=42, **kwargs)
        h.write('proc/777124/cgroup', '0::' + GROUP + '\n')
        return h

    def active_snapshot(self):
        return snapshot(ActiveState='active', SubState='running', MainPID='777124',
                        InvocationID=INVOCATION, ControlGroup=GROUP)

    def test_startup_empty_id_waits_then_binds_same_single_client(self):
        for description in [DESCRIPTION, PUB]:
            for code in [0, 2]:
                with self.subTest(description=description, code=code):
                    h = self.prepared_unbound(code=code, polls=[None, None, None])
                    h.service_sequence = [snapshot(Description=description),
                        snapshot(ActiveState='activating', SubState='start-pre'), self.active_snapshot()]
                    r = h.run()
                    self.assertEqual(r.returncode, code)
                    self.assertEqual(h.j['publisher_client_returncode'], code)
                    self.assertEqual(h.spawn_calls, 1)
                    self.assertEqual(h.reap_calls, 0)
                    self.assertAlmostEqual(h.wait_timeout_value, 39.9)
                    self.assertEqual([x[2] for x in h.calls if x[0] == 'service'], [140, 140, 140])
                    self.assertFalse(any(x[0] == 'command' for x in h.calls))
                    self.assertEqual(h.j['publisher_admission_first_observation']['ActiveState'], 'inactive')
                    self.assertEqual(h.j['publisher_admission_last_observation']['SubState'], 'running')

    def test_startup_empty_id_with_each_partial_binding_waits_for_completion(self):
        for missing in ['publisher_invocation_id', 'publisher_cgroup', 'publisher_process_identity']:
            with self.subTest(missing=missing):
                h = self.harness(process_birth=42, polls=[None, None])
                del h.j[missing]
                h.write('proc/777124/cgroup', '0::' + GROUP + '\n')
                h.service_sequence = [snapshot(), self.active_snapshot()]
                self.assertEqual(h.run().returncode, 2)
                self.assertEqual(h.j['publisher_admission_first_observation']['prior_binding_components'], 2)
                self.assertEqual(h.spawn_calls, 1)
                self.assertEqual(h.reap_calls, 0)

    def test_unbound_empty_id_observation_never_grants_stop_or_identity(self):
        for u in [snapshot(), snapshot(Description=PUB),
                  snapshot(LoadState='not-found', Description=PUB),
                  snapshot(ActiveState='activating', SubState='start-pre', MainPID='777124', ControlGroup=GROUP)]:
            with self.subTest(u=u):
                h = self.harness(binding=False, terminal=u, polls=[None] * 20)
                with self.assertRaisesRegex(RuntimeError, 'original_maintenance_budget_exhausted'):
                    h.run(deadline=100.11)
                self.assertIsNone(h.j['publisher_client_returncode'])
                for key in ['publisher_invocation_id', 'publisher_cgroup', 'publisher_process_identity']:
                    self.assertNotIn(key, h.j)
                self.assertEqual(h.spawn_calls, 1)
                self.assertEqual(h.reap_calls, 1)
                self.assertEqual(h.child.returncode, -9)
                self.assertTrue(all(x[2] == 100.11 for x in h.calls if x[0] == 'service'))
                self.assertFalse(any(x[0] == 'command' for x in h.calls))
                self.assertIsNone(h.wait_timeout_value)

    def test_startup_foreign_nonce_description_refuses_without_stop(self):
        for load in ['loaded', 'not-found']:
            h = self.harness(binding=False, terminal=snapshot(LoadState=load, Description='foreign-known-nonce'))
            with self.assertRaisesRegex(AssertionError, 'publisher_name_conflict_no_authority_to_stop'):
                h.run()
            self.assertIsNone(h.j['publisher_client_returncode'])
            self.assertEqual(h.j['publisher_admission_first_observation']['description_relation'], 'foreign')
            self.assertEqual(h.reap_calls, 1)
            self.assertFalse(any(x[0] == 'command' for x in h.calls))
            self.assertNotIn('publisher_invocation_id', h.j)

    def test_default_description_with_any_identity_component_is_not_placeholder(self):
        for change in [dict(InvocationID=INVOCATION), dict(MainPID='777124'),
                       dict(ControlPID='777125'), dict(ControlGroup=GROUP)]:
            h = self.harness(binding=False, terminal=snapshot(Description=PUB, **change))
            with self.assertRaisesRegex(AssertionError, 'publisher_name_conflict_no_authority_to_stop'):
                h.run()
            self.assertIsNone(h.wait_timeout_value)
            self.assertFalse(any(x[0] == 'command' for x in h.calls))
            self.assertNotIn('publisher_invocation_id', h.j)

    def test_empty_id_matching_nonce_with_pid_only_is_observed_without_acquisition(self):
        h = self.prepared_unbound(polls=[None, None])
        def bind_later():
            self.assertNotIn('publisher_invocation_id', h.j)
            self.assertNotIn('publisher_process_identity', h.j)
            self.assertNotIn('publisher_cgroup', h.j)
            return self.active_snapshot()
        h.service_sequence = [snapshot(ActiveState='activating', SubState='start', MainPID='777124', ControlGroup=GROUP), bind_later]
        self.assertEqual(h.run().returncode, 2)
        self.assertTrue(h.j['publisher_admission_first_observation']['main_pid_present'])
        self.assertFalse(h.j['publisher_admission_first_observation']['invocation_present'])

    def test_client_ends_before_full_binding_keeps_actual_code_and_refuses(self):
        for code in [0, 2, 17, -15]:
            for description in [DESCRIPTION, PUB]:
                h = self.harness(binding=False, terminal=snapshot(Description=description), polls=[None, code])
                with self.assertRaisesRegex(AssertionError, 'publisher_finished_without_exact_binding'):
                    h.run()
                self.assertEqual(h.j['publisher_client_returncode'], code)
                self.assertEqual(h.child.returncode, code)
                self.assertEqual(h.spawn_calls, 1)
                self.assertEqual(h.reap_calls, 1)
                self.assertIsNotNone(h.wait_timeout_value)
                self.assertFalse(any(x[0] == 'command' for x in h.calls))
                self.assertTrue(any(x.get('publisher_client_returncode') == code for x in h.saves))

    def test_full_binding_empty_id_active_state_still_fails_strict_terminal_proof(self):
        h = self.harness(terminal=snapshot(ActiveState='activating', SubState='start-pre'))
        with self.assertRaises(AssertionError):
            h.run()
        self.assertIsNone(h.j['publisher_client_returncode'])
        self.assertIsNone(h.wait_timeout_value)
        self.assertNotIn('publisher_admission_first_observation', h.j)
        self.assertEqual(h.reap_calls, 1)

    def test_observation_states_are_fixed_and_exclude_args_messages_pids_and_nonce(self):
        h = self.harness(binding=False, terminal=snapshot(LoadState='secret-load', ActiveState='secret-active',
                          SubState='secret-substate', Arbitrary='private-data'), polls=[None, 2])
        with self.assertRaisesRegex(AssertionError, 'publisher_finished_without_exact_binding'):
            h.run()
        first = h.j['publisher_admission_first_observation']
        self.assertEqual({key: first[key] for key in ['LoadState', 'ActiveState', 'SubState']},
                         dict(LoadState='unsupported', ActiveState='unsupported', SubState='unsupported'))
        self.assertEqual(set(first), {'LoadState', 'ActiveState', 'SubState', 'description_relation',
                         'invocation_present', 'main_pid_present', 'control_pid_present', 'cgroup_present',
                         'prior_binding_components', 'client_observed_alive'})
        serialized = json.dumps(first)
        for text in ['secret', 'private-data', DESCRIPTION, INVOCATION, GROUP, '777124']:
            self.assertNotIn(text, serialized)

    def test_repeated_placeholder_does_not_repeat_fsync_for_unchanged_state(self):
        h = self.harness(binding=False, polls=[None, None, None, 2])
        with self.assertRaisesRegex(AssertionError, 'publisher_finished_without_exact_binding'):
            h.run()
        observations = [x for x in h.saves if 'publisher_admission_first_observation' in x
                        and x['publisher_client_returncode'] is None]
        self.assertEqual(len(observations), 1)
        self.assertEqual(h.spawn_calls, 1)

    def test_bound_wait_after_startup_uses_original_deadline_and_timeout_unknown(self):
        h = self.prepared_unbound(polls=[None, None], wait_timeout=True)
        h.service_sequence = [snapshot(), self.active_snapshot()]
        with self.assertRaises(subprocess.TimeoutExpired):
            h.run(deadline=101)
        self.assertAlmostEqual(h.wait_timeout_value, .95)
        self.assertEqual(h.reap_calls, 1)
        self.assertIsNone(h.j['publisher_client_returncode'])
        self.assertEqual(h.spawn_calls, 1)

    def test_observer_error_captures_actual_exit_before_cleanup(self):
        h = self.harness(binding=False, polls=[None, 17])
        def fail_service(*args, **kwargs):
            raise ValueError('fixed-test-error')
        h.ns['service'] = fail_service
        with self.assertRaisesRegex(ValueError, 'fixed-test-error'):
            h.run()
        self.assertEqual(h.j['publisher_client_returncode'], 17)
        self.assertEqual(h.child.returncode, 17)
        self.assertEqual(h.reap_calls, 1)
        self.assertEqual(h.saves[-1]['publisher_client_returncode'], 17)

    def test_conflicting_invocation_after_partial_binding_never_replaces_pin(self):
        h = self.prepared_unbound(polls=[None, None])
        h.j['publisher_invocation_id'] = INVOCATION
        h.service_sequence = [snapshot(), dict(self.active_snapshot(), InvocationID='b' * 32)]
        with self.assertRaisesRegex(AssertionError, 'publisher_invocation_changed'):
            h.run()
        self.assertEqual(h.j['publisher_invocation_id'], INVOCATION)
        self.assertNotIn('publisher_process_identity', h.j)
        self.assertIsNone(h.j['publisher_client_returncode'])
        self.assertFalse(any(x[0] == 'command' for x in h.calls))

    def test_unbound_not_found_never_uses_terminal_proof(self):
        h = self.prepared_unbound(polls=[None, None])
        h.service_sequence = [snapshot(LoadState='not-found', Description=PUB), self.active_snapshot()]
        def forbid_terminal(**kwargs):
            raise AssertionError('terminal-proof-must-not-run-before-binding')
        h.ns['publisher_terminal_proven'] = forbid_terminal
        self.assertEqual(h.run().returncode, 2)
        self.assertEqual(h.j['publisher_admission_first_observation']['LoadState'], 'not-found')

    def test_observation_metadata_alone_never_authorizes_cleanup_unit_stop(self):
        h = self.harness(binding=False, polls=[None, 2])
        with self.assertRaisesRegex(AssertionError, 'publisher_finished_without_exact_binding'):
            h.run()
        with self.assertRaises(AssertionError):
            h.close()
        self.assertFalse(any(x[0] == 'command' for x in h.calls))
        self.assertNotIn('publisher_closed_before_parent_custody_release', h.j)


    def test_spawn_failure_is_marked_before_any_child_identity_or_cleanup(self):
        h = self.harness(binding=False)
        def fail_spawn(*args, **kwargs):
            h.spawn_calls += 1
            raise OSError('fixed-inert-spawn-failure')
        h.ns['subprocess'].Popen = fail_spawn
        with self.assertRaisesRegex(OSError, 'fixed-inert-spawn-failure'):
            h.run()
        self.assertEqual(h.spawn_calls, 1)
        self.assertEqual(h.reap_calls, 0)
        self.assertTrue(h.j['publisher_client_spawn_failed_before_child_created'])
        self.assertNotIn('publisher_client_identity', h.j)
        self.assertNotIn('publisher_client_returncode', h.j)
        self.assertFalse(any(x[0] == 'service' for x in h.calls))

    def test_partial_invocation_acquired_then_empty_id_still_waits_until_full_binding(self):
        h = self.prepared_unbound(polls=[None, None, None])
        h.service_sequence = [snapshot(InvocationID=INVOCATION), snapshot(), self.active_snapshot()]
        self.assertEqual(h.run().returncode, 2)
        self.assertEqual(h.j['publisher_invocation_id'], INVOCATION)
        self.assertEqual(h.j['publisher_process_identity'], {'pid': 777124, 'birth_ticks': 42})
        self.assertEqual(h.reap_calls, 0)
        self.assertAlmostEqual(h.wait_timeout_value, 39.9)
        observed_components = [x['publisher_admission_last_observation']['prior_binding_components']
                               for x in h.saves if 'publisher_admission_last_observation' in x]
        self.assertIn(1, observed_components)

    def test_binding_process_read_failure_refuses_and_captures_known_client_exit(self):
        h = self.harness(binding=False, polls=[None, 2])
        h.current = self.active_snapshot()
        with self.assertRaises(FileNotFoundError):
            h.run()
        self.assertEqual(h.j['publisher_invocation_id'], INVOCATION)
        self.assertEqual(h.j['publisher_cgroup'], GROUP)
        self.assertNotIn('publisher_process_identity', h.j)
        self.assertEqual(h.j['publisher_client_returncode'], 2)
        self.assertEqual(h.reap_calls, 1)
        self.assertFalse(any(x[0] == 'command' for x in h.calls))


class Observer205Controls(ObserverControls):
    actor_number = 205


def verify_scope():
    changes = {'run_owned_publisher'}
    result = {}
    for n in [204, 205]:
        name = 'run_native' + str(n) + '_once.py'
        raw_before = (B / 'before' / name).read_text()
        raw_after = (B / 'candidate' / name).read_text()
        before, after = ast.parse(raw_before), ast.parse(raw_after)
        before_nodes = {x.name: x for x in before.body if isinstance(x, ast.FunctionDef)}
        after_nodes = {x.name: x for x in after.body if isinstance(x, ast.FunctionDef)}
        assert before_nodes.keys() == after_nodes.keys()
        changed = {k for k in before_nodes if ast.dump(before_nodes[k]) != ast.dump(after_nodes[k])}
        assert changed == changes, changed
        def unchanged_tree(t):
            t = copy.deepcopy(t)
            for i, node in enumerate(t.body):
                if isinstance(node, ast.FunctionDef) and node.name in changes:
                    t.body[i] = ast.Pass()
            return ast.dump(t)
        assert unchanged_tree(before) == unchanged_tree(after)
        result[str(n)] = {'changed_functions': sorted(changed),
                          'top_level_and_other_functions_ast_unchanged': True}
    return result


if __name__ == '__main__':
    scope = verify_scope()
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__('__main__'))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    report = {'schema': 'core204.publisher-terminal-observer-source-controls.v1',
              'tests_run': result.testsRun, 'failures': len(result.failures),
              'errors': len(result.errors), 'successful': result.wasSuccessful(),
              'elapsed_seconds': round(time.monotonic() - START, 6),
              'cpu_affinity_count': len(os.sched_getaffinity(0)),
              'limits': {'wall_alarm': 90, 'cpu': 60, 'address_space_mib': 512},
              'no_live_units_or_process_effects': True,
              'scope': scope}
    (B / 'evidence' / 'control-results.json').write_text(json.dumps(report, indent=2) + '\n')
    assert time.monotonic() - START < 90
    signal.alarm(0)
    raise SystemExit(0 if result.wasSuccessful() else 1)
