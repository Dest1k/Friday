"""Exact AST-extracted effective-origin predicate, no boundary/product execution."""
from pathlib import Path
from types import SimpleNamespace
import ast, json

B = Path(__file__).parent
t = ast.parse((B/'core204-r2-actual-root.py').read_bytes())
f = next(n for n in t.body if isinstance(n, ast.FunctionDef) and n.name == 'boundary')
n = f.body[1]
assert isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and n.value.func.id == 'require'
code = compile(ast.Module(body=[n], type_ignores=[]), '<exact-origin-require>', 'exec')
rows = []
for url, accepted in [
    ('https://github.com/Dest1k/Friday', True),
    ('https://github.com/Dest1k/Friday.git', True),
    ('https://github.com/Dest1k/Friday.git\n', True),
    ('http://github.com/Dest1k/Friday.git', False),
    ('https://github.com/Dest1k/Other.git', False),
    ('https://github.com/other/Friday.git', False),
    ('https://github.com.example/Dest1k/Friday.git', False),
    ('https://github.com/alinescafs3mp-afk/friday_rework.git', False),
]:
    def require(ok, reason):
        if not ok: raise ValueError(reason)
    try:
        exec(code, {'run': lambda argv: SimpleNamespace(stdout=url),
                    'R': Path('/DECLARED/SYNTHETIC_ONLY'), 'require': require})
        actual = True
    except ValueError:
        actual = False
    assert actual is accepted
    rows.append({'origin': url.strip(), 'expected_acceptance': accepted, 'actual_acceptance': actual})
out = dict(state='PASS_EXACT_EFFECTIVE_ORIGIN_PREDICATE_SOURCE_ONLY', count=len(rows), rows=rows,
           no_boundary_import_or_live_effects=True,
           old_defect='Exact prior code rejected observed configured .git URL before any transaction.')
with (B/'ORIGIN-URL-CONTROLS.json').open('x') as stream:
    json.dump(out, stream, ensure_ascii=False, indent=2)
print(json.dumps(dict(state=out['state'], count=len(rows))))
