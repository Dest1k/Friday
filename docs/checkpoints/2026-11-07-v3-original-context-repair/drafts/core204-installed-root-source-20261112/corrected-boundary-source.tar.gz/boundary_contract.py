"""Pure R2 source contracts. These checks cannot authenticate Root observations."""
import datetime

class InvalidBoundary(ValueError): pass

def require(value, reason):
    if not value: raise InvalidBoundary(reason)

def fresh(value, current_time):
    try:
        instant = datetime.datetime.fromisoformat(value)
        require(instant.utcoffset() is not None, 'anchor_timezone_required')
        require(0 <= current_time - instant.timestamp() <= 300, 'anchor_stale_or_future')
    except (TypeError, ValueError, OverflowError) as exc:
        raise InvalidBoundary('anchor_stale_or_future') from exc

def digest(value, length=64):
    return type(value) is str and len(value) == length and all(c in '0123456789abcdef' for c in value)

def validate_authority(value, *, manifest, boundary, caller, policy, source_acceptance, anchor, frame):
    require(value['schema'] == 'frw.root204.r2-reviewed-origin-execution.v1' and
            value['state'] == 'ROOT_REVIEWED_R2_MISSING204_BOUNDARY_FUTURE_EXECUTION' and
            value['template_only_no_execution_grant'] is False, 'fresh_Root_authority_required')
    expected = dict(source_pin_manifest=manifest, boundary=boundary, caller=caller,
                    origin_policy=policy, boundary_source_acceptance=source_acceptance,
                    current_service_anchor=anchor)
    require(all(value[k] == v for k,v in expected.items()), 'exact_reviewed_R2_authority_required')
    require(value['frame'] == frame and digest(value['execution_commit'],40), 'exact_frame_and_current_commit_required')
    mode=value['provenance_mode']; require(mode in ('local-committed-main','published-remote'), 'explicit_origin_mode_required')
    require(value['origin_url'] == 'https://github.com/Dest1k/Friday', 'effective_origin_required')
    require(value['immutable_source204_public_main_sha'] == '48de25314b76528b8525674097947a45750c46d3', 'immutable204_origin_required')
    require(value['public_main_sha'] is None if mode == 'local-committed-main' else
            value['public_main_sha'] == value['execution_commit'], 'current_origin_mode_mismatch')
    require(value['genuinely_missing_source_install_after_reconciliation'] is True and
            value['old_consumed_launch_not_replayed'] is True, 'distinct_missing_install_authority_required')

def validate_anchor(value, *, current_time, boot, historical, expected_request_sha256, frame, publisher):
    require(value['schema'] == 'frw.root204.r2-current-service-anchor.v1' and
            value['state'] == 'ROOT_ACTUAL_RECONCILED_CURRENT203_BOUNDARY' and
            value['template_only_no_execution_grant'] is False, 'actual_Root_current_anchor_required')
    fresh(value['observed_at_moscow'], current_time)
    require(value['boot_id'] == boot and type(boot) is str and len(boot)==36, 'current_boot_anchor_required')
    require(value['historical_evidence'] == historical, 'exact_historical_reconciliation_required')
    require(value['frame'] == frame and value['future_publisher_unit'] == publisher, 'R2_frame_publisher_required')
    require(value['expected_request_sha256'] == expected_request_sha256 and digest(expected_request_sha256), 'deterministic_request_identity_required')
    require(value['installed'] == dict(layers=203,project=487,nativefiles=17891,plugins=52,base_source_file_count=17730,
            receipt_sha256='9d8d1d954a59d5f944cb0b33c11cba3bba845cbb5d71088f335d68077c2a83c2',
            input_sha256='31178b28f928c937118d5c58df5aa15bb9fe23f748979cbdd9cb2f1456f513ad'), 'genuine_current203_anchor_required')
    fields=('old_publisher_launch_consumed_preserved','old_publisher_and_client_ceased','old_actor_ceased',
            'old_source_transaction_wholly_absent','genuinely_missing_source_install_stage',
            'original_unknown_and_clocks_preserved','current_all_profile_owned_work_quiescent',
            'current_cancel_stop_cooldown_clear','current_no_maintenance','current_resources_sufficient')
    require(set(value['checks'])==set(fields) and all(value['checks'][x] is True for x in fields), 'all_Root_reconciliation_checks_required')
    require(value['evidence'] and all(type(r) is dict and set(r)=={'path','sha256'} and digest(r['sha256']) for r in value['evidence']), 'actual_anchor_evidence_required')
    require(all(r not in historical.values() and 'UNBOUND' not in r['path'] and not r['path'].endswith('-TEMPLATE.json') for r in value['evidence']), 'historical_or_template_evidence_not_current')
    require(set(value['services'])==set(('gateway','dashboard')) and set(value['process_environment'])==set(('gateway','dashboard')), 'both_current_services_required')
    for label, row in value['services'].items():
        require(set(row)==set(('pid','birth_ticks','boot_id','invocation_id','cgroup','enabled_active','runtime_max')), 'exact_service_identity_fields_required')
        require(type(row['pid']) is int and row['pid']>0 and type(row['birth_ticks']) is int and row['birth_ticks']>0 and row['boot_id']==boot and digest(row['invocation_id'],32) and row['cgroup'].startswith('/user.slice/') and row['enabled_active'] is True and row['runtime_max']=='infinity', 'current_service_identity_required')
        require(value['process_environment'][label].get('HERMES_HOME') == value['home'], 'current_service_environment_required')

def compare_service(actual, expected, actual_environment, expected_environment):
    require(actual == expected, 'current_service_identity_changed')
    require(actual_environment == expected_environment, 'current_service_environment_changed')

def guard_absent(paths, lexists):
    for path in paths: require(not lexists(path), 'consumed_output_or_transaction_exists:'+str(path))
