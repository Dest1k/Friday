"""Finite pure synthetic controls. Never import/execute boundary, launcher or actor."""
import ast,copy,datetime,hashlib,importlib.util,json,os,pathlib,resource,time
B=pathlib.Path(__file__).parent
resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,cpus[:2])
start=time.monotonic();spec=importlib.util.spec_from_file_location('pure_r2_boundary_contract',B/'boundary_contract.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
checks=[]
def check(name,call,negative=False):
    try:call()
    except (c.InvalidBoundary,KeyError):
        assert negative,name;checks.append(dict(name=name,result='REFUSED_EXPECTED'));return
    assert not negative,name;checks.append(dict(name=name,result='PASS'))
T=datetime.datetime(2026,11,12,1,tzinfo=datetime.timezone.utc).timestamp();stamp=datetime.datetime.fromtimestamp(T,datetime.timezone.utc).isoformat()
R=lambda name:dict(path='/SYNTHETIC_ONLY/'+name,sha256='a'*64)
args=dict(manifest=R('manifest'),boundary=R('boundary'),caller=R('caller'),policy=R('policy'),source_acceptance=R('source_acceptance'),anchor=R('anchor'),frame='/SYNTHETIC_ONLY/frame')
a=dict(schema='frw.root204.r2-reviewed-origin-execution.v1',state='ROOT_REVIEWED_R2_MISSING204_BOUNDARY_FUTURE_EXECUTION',template_only_no_execution_grant=False,source_pin_manifest=args['manifest'],boundary=args['boundary'],caller=args['caller'],origin_policy=args['policy'],boundary_source_acceptance=args['source_acceptance'],current_service_anchor=args['anchor'],frame=args['frame'],execution_commit='b'*40,provenance_mode='local-committed-main',public_main_sha=None,origin_url='https://github.com/Dest1k/Friday',immutable_source204_public_main_sha='48de25314b76528b8525674097947a45750c46d3',genuinely_missing_source_install_after_reconciliation=True,old_consumed_launch_not_replayed=True)
check('synthetic_local_authority_schema',lambda:c.validate_authority(a,**args))
for name,key,value in [('template_authority','template_only_no_execution_grant',True),('old_state','state','ROOT_REVIEWED_EXACT204_PUBLISHED_PREFIX_FUTURE_EXECUTION'),('local_with_remote','public_main_sha','b'*40),('wrong_origin','origin_url','https://github.com/old/Friday'),('source204_current_conflation','immutable_source204_public_main_sha','b'*40),('missing_install_not_reconciled','genuinely_missing_source_install_after_reconciliation',False),('wrong_frame','frame','/OLD')]:
    x=copy.deepcopy(a);x[key]=value;check(name,lambda x=x:c.validate_authority(x,**args),True)
boot='00000000-0000-0000-0000-000000000001';service=dict(pid=12345,birth_ticks=1000,boot_id=boot,invocation_id='c'*32,cgroup='/user.slice/SYNTHETIC_ONLY',enabled_active=True,runtime_max='infinity')
fields=('old_publisher_launch_consumed_preserved','old_publisher_and_client_ceased','old_actor_ceased','old_source_transaction_wholly_absent','genuinely_missing_source_install_stage','original_unknown_and_clocks_preserved','current_all_profile_owned_work_quiescent','current_cancel_stop_cooldown_clear','current_no_maintenance','current_resources_sufficient')
anchor=dict(schema='frw.root204.r2-current-service-anchor.v1',state='ROOT_ACTUAL_RECONCILED_CURRENT203_BOUNDARY',template_only_no_execution_grant=False,observed_at_moscow=stamp,boot_id=boot,historical_evidence={'historical_only':R('old')},frame=args['frame'],future_publisher_unit='SYNTHETIC.service',expected_request_sha256='d'*64,home='/SYNTHETIC_ONLY/home',installed=dict(layers=203,project=487,nativefiles=17891,plugins=52,base_source_file_count=17730,receipt_sha256='9d8d1d954a59d5f944cb0b33c11cba3bba845cbb5d71088f335d68077c2a83c2',input_sha256='31178b28f928c937118d5c58df5aa15bb9fe23f748979cbdd9cb2f1456f513ad'),checks={k:True for k in fields},evidence=[R('fresh')],services={k:copy.deepcopy(service) for k in ('gateway','dashboard')},process_environment={k:{'HERMES_HOME':'/SYNTHETIC_ONLY/home'} for k in ('gateway','dashboard')})
kw=dict(current_time=T,boot=boot,historical=anchor['historical_evidence'],expected_request_sha256='d'*64,frame=args['frame'],publisher='SYNTHETIC.service')
check('synthetic_anchor_schema_only',lambda:c.validate_anchor(anchor,**kw))
for name,key,value in [('stale_anchor','observed_at_moscow',datetime.datetime.fromtimestamp(T-301,datetime.timezone.utc).isoformat()),('future_anchor','observed_at_moscow',datetime.datetime.fromtimestamp(T+1,datetime.timezone.utc).isoformat()),('template_anchor','template_only_no_execution_grant',True),('wrong_boot','boot_id','other'),('old_publisher','future_publisher_unit','OLD.service'),('wrong_request','expected_request_sha256','e'*64)]:
    x=copy.deepcopy(anchor);x[key]=value;check(name,lambda x=x:c.validate_anchor(x,**kw),True)
x=copy.deepcopy(anchor);x['evidence']=list(kw['historical'].values());check('historical_closure_as_current_anchor_evidence',lambda:c.validate_anchor(x,**kw),True)
for key in fields:
    x=copy.deepcopy(anchor);x['checks'][key]=False;check('reject_missing_'+key,lambda x=x:c.validate_anchor(x,**kw),True)
for key,value in [('pid',12346),('birth_ticks',1001),('invocation_id','e'*32),('cgroup','/user.slice/other'),('boot_id','other')]:
    actual=copy.deepcopy(service);actual[key]=value;check('live_'+key+'_mismatch',lambda actual=actual:c.compare_service(actual,service,{'HERMES_HOME':'/x'},{'HERMES_HOME':'/x'}),True)
check('live_environment_mismatch',lambda:c.compare_service(service,service,{'HERMES_HOME':'/x'},{'HERMES_HOME':'/y'}),True)
check('whole_tx_exists',lambda:c.guard_absent(['/SYNTHETIC_ONLY/tx'],lambda p:True),True)
check('dangling_symlink_lexists_not_exists',lambda:c.guard_absent(['/SYNTHETIC_ONLY/dangling'],lambda p:True),True)
check('consumed_output_exists',lambda:c.guard_absent(['/SYNTHETIC_ONLY/once'],lambda p:True),True)
check('all_unconsumed',lambda:c.guard_absent(['/SYNTHETIC_ONLY/tx'],lambda p:False))
for name in ('core204-r2-actual-root.py','start_core204_r2_once.py','boundary_contract.py','source_controls.py','prepare_source.py','finalize_source.py'):
    source=(B/name).read_text();ast.parse(source);compile(source,str(B/name),'exec')
    checks.append(dict(name='AST_compile_only_'+name,result='PASS'))
s=(B/'core204-r2-actual-root.py').read_text();t=ast.parse(s)
assert 'EXPECTED_SERVICES' not in s and '174854' not in s and '175894' not in s
assert "'frw-astra-native204-install-r2-20261112.service'" in s
assert 'full_native_readback(receipt)' in s and "len(receipt['files'])==17891" in s
assert s.count("os.path.lexists(H/'preparation'/('ordinary-source-update-v45-'")>=3
assert 'pass_fds=(slotfd,)' in s and 'fcntl.LOCK_UN' not in s.replace('# Never LOCK_UN','')
assert 'code = wait_same_child(child)' in s and 'if child is not None and child.returncode is None: wait_same_child(child)' in s
assert 'time.sleep' not in s and 'OLD_REQUEST_SHA' in s
assert s.index("final = boundary(") < s.index("result = launch_once(")
checks.append(dict(name='AST_changed_boundary_and_custody_guards',result='PASS'))
generator=ast.parse((B/'prepare_source.py').read_text())
generator.body=[n for n in generator.body if not isinstance(n,ast.FunctionDef) or n.name!='save']
capture={}
exec(compile(generator,str(B/'prepare_source.py'),'exec'),{'__file__':str(B/'prepare_source.py'),'save':lambda name,value:capture.update({name:value})})
assert capture=={'core204-r2-actual-root.py':s}
checks.append(dict(name='source_generator_reproduces_exact_boundary_in_memory_only',result='PASS'))
assert "only_docs_may_advance_reference_main" in s
assert s.rindex('contract.validate_anchor(anchor,') < s.index('result = launch_once(')
checks.append(dict(name='AST_docs_only_reference_and_last_anchor_freshness',result='PASS'))
pins=json.loads((B/'SOURCE-PINS.json').read_text())
for path,digest in {**pins['source_refs'],**pins['historical_refs']}.items():assert hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()==digest,path
assert str(B/'core204-r2-actual-root.py') in pins['source_refs'] and str(B/'start_core204_r2_once.py') in pins['source_refs']
assert not any(path.endswith('/ROOT-204-SOURCE-ACCEPTANCE.json') for path in pins['source_refs'])
checks.append(dict(name='closed_source_manifest_current_authorities_excluded',result='PASS'))
for name in ('ROOT-204-ORIGIN-AUTHORITY-TEMPLATE.json','ROOT-204-CURRENT-SERVICE-ANCHOR-TEMPLATE.json','ROOT-R2-BOUNDARY-SOURCE-ACCEPTANCE-TEMPLATE.json'):
    value=json.loads((B/name).read_text());assert value['template_only_no_execution_grant'] is True
    assert 'UNBOUND' in value['state'];checks.append(dict(name='template_remains_unbound_'+name,result='PASS'))
assert time.monotonic()-start<90
out=dict(schema='frw.root204.r2-source-controls.v1',state='PASS_PURE_SYNTHETIC_AND_AST_SOURCE_ONLY',controls=checks,count=len(checks),elapsed_seconds=time.monotonic()-start,budgets=dict(wall=90,cpu=60,memory_bytes=512*1024**2,affinity_cpus=sorted(os.sched_getaffinity(0))),boundary_launcher_actor_imported_or_executed=False,actual_Root_record_created=False,live_or_product_effects=0,meaning='Synthetic schema acceptance proves only pure contract behavior; never current Root authority/readback.')
with (B/'SOURCE-CONTROLS.json').open('x') as f:json.dump(out,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(state=out['state'],count=len(checks),elapsed_seconds=out['elapsed_seconds'])))
