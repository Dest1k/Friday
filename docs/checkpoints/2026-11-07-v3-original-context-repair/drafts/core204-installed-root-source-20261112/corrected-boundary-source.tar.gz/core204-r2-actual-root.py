"""Future R2 Root204 boundary; SOURCE ONLY, unbound until authentic Root inputs. Preparation/import is inert; explicit main has live effects.

Adapted from accepted core203-first-actual-root.py; no historical script is run.
Root reviews this source before invoking it. No retry, restored clock, user replay,
Office effect or claim of power-loss atomicity. Actor owns original1800 clock.
"""
import datetime, fcntl, hashlib, json, os, signal, sqlite3, stat, subprocess, sys, time, types
from pathlib import Path
from zoneinfo import ZoneInfo

B = Path(__file__).parent
R = Path('/home/jericho/jericho/Friday_rework')
H = R / '.runtime/friday-normal-both-workers-frw032'
F = Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE204-FUTURE-FRAME-R2-20261112')
E = B / 'FUTURE-EXECUTION'
PUB = 'frw-astra-native204-install-r2-20261112.service'
OLDPUB = 'frw-astra-native204-publication-20261111.service'
S = Path('/home/jericho/.cache/FRW-SOL-V3-CORE204-RTF-READER-COMPOSITION-20261111')
F203 = Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE203-ROOT-MAINTENANCE-FRAME-20261111')
APP = Path('/home/jericho/.cache/FRW-ASTRA-V3-ODP-NEW-CREATOR-APP-RECIPE-20261111/app_contract.py')
GATE = Path('/home/jericho/.cache/FRW-ASTRA-V3-CORE-F01-BOUND-TESTER-PREP-20261111/gate202.py')
RUNTIME = Path('/home/jericho/.cache/FRW-ASTRA-V3-V03-RECEIVED-PPTX-MISSING-APP-20261111/ROOT-FRESH-RUNTIME-PROOF.json')
BANK = Path('/home/jericho/.cache/FRW-ASTRA-V3-ODP-APP-ROOT-FRAME-PREP-20261111/BANK-PHYSICAL-INTEGRITY.json')
# Acyclic freeze: Root supplies the externally reviewed manifest SHA via argv.
BEFORE = '9d8d1d954a59d5f944cb0b33c11cba3bba845cbb5d71088f335d68077c2a83c2'
INPUT203 = '31178b28f928c937118d5c58df5aa15bb9fe23f748979cbdd9cb2f1456f513ad'
AFTER = '94aea3888c0c89b99022cda3259b7e947d063d91d8525ddbff5bd4df3ac98d6a'
OLD_REQUEST_SHA = 'd834da5fe0a1232d6e5be6f12ff0bccbe868ce5280f9821259406e60f1240a65'
LIMITS = dict(native_canonical_unknown=3, structural_unresolved=45,
              R104_semantic_fail=True, default_workers_ready_accepted=False, DSH_A0_deferred=True)

def require(value, reason):
    if not value: raise RuntimeError(reason)

def now(): return datetime.datetime.now(ZoneInfo('Europe/Moscow')).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())

def metadata(path):
    path = Path(path); v = path.lstat()
    require(stat.S_ISREG(v.st_mode) and v.st_uid == os.getuid() and v.st_nlink == 1 and
            not any(p.is_symlink() for p in (path, *path.parents)), 'owned_regular_no_link:' + str(path))
    return [v.st_dev, v.st_ino, v.st_uid, v.st_gid, v.st_mode, v.st_nlink]

def ref(path):
    metadata(path)
    return dict(path=str(path), sha256=sha(path))

def save(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as out: out.write(raw); out.flush(); os.fsync(out.fileno())
    parent = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(parent)
    finally: os.close(parent)

def run(argv, timeout=20):
    return subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True, timeout=timeout, check=True)

def module(path, name):
    m = types.ModuleType(name); m.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), 'exec'), m.__dict__)
    return m

def birth(pid): return int((Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[19])

def wait_same_child(child):
    """No deadline/retry/new child: actor's original finite clock or custody hold governs."""
    while True:
        try: return child.wait()
        except (InterruptedError, KeyboardInterrupt): continue

def launch_once(argv, slotfd, boot):
    """Hold same flock open-description in exact child; defer parent INT/TERM until wait.

    Kernel/pin/report exceptions after Popen still await this child. Its explicit
    STOP_UNCONFIRMED custody hold intentionally keeps parent waiting and slot held.
    SIGKILL/power loss cannot be deferred; inherited fd is process-death insurance,
    not transactional storage or power-loss atomicity.
    """
    pending = []; child = None; code = None; started = time.monotonic()
    previous = {s: signal.getsignal(s) for s in (signal.SIGINT, signal.SIGTERM)}
    def defer(signum, _frame): pending.append(signum)
    for s in previous: signal.signal(s, defer)
    try:
        with (E / 'core204-actual-actor.stdout').open('xb') as out, (E / 'core204-actual-actor.stderr').open('xb') as err:
            require(not pending, 'parent_stop_requested_before_actor')
            child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                     close_fds=True, pass_fds=(slotfd,), start_new_session=True)
            try:
                save(E / 'CORE204-ROOT-ONCE-ACTOR-LAUNCHED.json', dict(pid=child.pid,
                     birth_ticks=birth(child.pid), boot_id=boot, actor=ref(F / 'run_native204_once.py'),
                     once_only=True, shared_slot_held_by_Root_parent=os.getpid(), inherited_slot_fd=slotfd))
            finally:
                # Includes failed birth read/ref/save, BaseException and parent signals.
                code = wait_same_child(child)
        return dict(returncode=code, elapsed_Root_seconds=time.monotonic()-started,
                    deferred_parent_signals=pending, no_retry=True)
    finally:
        # An unexpected exception from local report handling must never release a live actor.
        if child is not None and child.returncode is None: wait_same_child(child)
        for s, handler in previous.items(): signal.signal(s, handler)

def readonly_databases():
    rows = {}; deadline = time.monotonic() + 15
    for label, rel in [('default', 'state.db'), ('dest', 'profiles/dest_telegram/state.db'),
                       ('tester', 'profiles/telegram-bot-8812646969/state.db')]:
        with sqlite3.connect((H / rel).as_uri() + '?mode=ro', uri=True, timeout=2) as db:
            db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 10000)
            db.execute('PRAGMA query_only=ON'); db.execute('BEGIN')
            row = dict(quick_check=db.execute('PRAGMA quick_check').fetchone()[0],
                       leases=db.execute('SELECT count(*) FROM session_turn_leases').fetchone()[0],
                       messages=db.execute('SELECT count(*) FROM messages').fetchone()[0],
                       sessions=db.execute('SELECT count(*) FROM sessions').fetchone()[0])
            db.rollback(); require(row['quick_check'] == 'ok' and row['leases'] == 0, 'DB_not_quiescent:' + label)
            rows[label] = row
    # Counts are freshly derived, including any completed M14 query; never fixed5504.
    return rows

def collect_services(boot, anchor, contract):
    services = {}; environments = {}
    keys = 'LoadState,ActiveState,SubState,MainPID,ControlPID,ControlGroup,InvocationID,UnitFileState,RuntimeMaxUSec,NRestarts'
    for label, unit in [('gateway', 'hermes-gateway-1b7e7667.service'), ('dashboard', 'hermes-dashboard.service')]:
        t = dict(x.split('=', 1) for x in run(['/usr/bin/systemctl', '--user', 'show', unit, '--property='+keys]).stdout.splitlines() if '=' in x)
        pid = int(t['MainPID']); ticks = birth(pid); proc = Path('/proc') / str(pid)
        require(all(t[k] == v for k, v in dict(LoadState='loaded', ActiveState='active', SubState='running',
                    UnitFileState='enabled', RuntimeMaxUSec='infinity', NRestarts='0', ControlPID='0').items()), 'permanent_service_unhealthy')
        require(len(t['InvocationID']) == 32 and ('0::'+t['ControlGroup']) in (proc/'cgroup').read_text().splitlines(), 'service_kernel_cgroup_changed')
        selected = {'HERMES_HOME', 'HERMES_GATEWAY_LOCK_DIR', 'HERMES_RUNTIME_DIR', 'HERMES_INSTALL_ROOT', 'HERMES_PROFILE'}
        env = {k.decode():v.decode() for row in (proc/'environ').read_bytes().split(b'\0')
               for k, sep, v in [row.partition(b'=')] if sep and k.decode() in selected}
        require(env.get('HERMES_HOME') == str(H), 'process_environment_home_changed')
        environments[label] = env
        services[label] = dict(pid=pid, birth_ticks=ticks, boot_id=boot, invocation_id=t['InvocationID'],
                               cgroup=t['ControlGroup'], enabled_active=True, runtime_max='infinity')
        contract.compare_service(services[label], anchor['services'][label], env, anchor['process_environment'][label])
        require(birth(pid)==ticks, 'service_birth_changed_during_collection')
    return services, environments

def boundary(m, c, transport, pins, op, anchor, contract, slot, slot_info, *, bank_check=True):
    head = run(['git', '-C', str(R), '--no-optional-locks', 'rev-parse', 'HEAD']).stdout.strip()
    require(run(['git','-C',str(R),'--no-optional-locks','remote','get-url','origin']).stdout.strip() in ('https://github.com/Dest1k/Friday','https://github.com/Dest1k/Friday.git'), 'effective_origin_url_changed')
    mode = pins['execution_provenance_mode']
    require(mode in ('published-remote','local-committed-main'), 'explicit_provenance_mode_required')
    origin = None
    if mode == 'published-remote':
        origin = run(['git', '-C', str(R), '--no-optional-locks', 'ls-remote', '--exit-code', 'origin', 'refs/heads/main']).stdout.split()[0]
    require(origin == pins['execution_public_main_sha'], 'exact_remote_observation_required')
    origin_proof = m.source_origin(pins['execution_commit'], origin, provenance_mode=mode)
    require(head == origin_proof['current_head'], 'head_changed_during_origin_check')
    reference='99f10f54e5e2989a3ec9c88b002d1fb3cacf4e3a'
    m.origin_git(R,'merge-base','--is-ancestor',reference,head)
    changed=m.origin_git(R,'diff','--no-renames','--name-only','-z',reference,head).split(b'\0')
    require(all(name.startswith(b'docs/') for name in changed if name), 'only_docs_may_advance_reference_main')
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    contract.validate_anchor(anchor, current_time=time.time(), boot=boot, historical=pins['historical_reconciliation'], expected_request_sha256=OLD_REQUEST_SHA, frame=str(F), publisher=PUB)
    require(anchor['home']==str(H), 'current_anchor_home_required')
    for evidence in anchor['evidence']: require(ref(evidence['path'])==evidence, 'fresh_anchor_evidence_changed')
    assert_old_ceased(pins, anchor)
    for path, digest in op['restore_verified_inputs']['settled_files'].items(): require(sha(path) == digest, 'accepted203_afterimage_drift')
    for path, identity in op['unchanged_metadata'].items(): require(metadata(path) == identity, 'route_or_service_metadata_drift')
    receipt = load(H/'hermes-agent.source.json'); marker = load(H/'FRIDAY-INSTALL.json'); stamp = load(H/'hermes-agent/install-stamp.json')
    require(sha(H/'hermes-agent.source.json') == BEFORE and marker['input_sha256'] == INPUT203 and
            marker['source_receipt_sha256'] == BEFORE and (len(receipt['layers']), len(receipt['files']), receipt['source_file_count'], len(marker['plugin_files'])) == (203,17891,17730,52), 'current203_tuple_required')
    require(stamp['fridaySource']['layers'] == receipt['layers'] and stamp['fridaySource']['baseTree'] == receipt['base_tree'], 'current_stamp_mismatch')
    for name, digest in marker['plugin_files'].items(): require(sha(H/name) == digest, 'plugin_pin_drift:'+name)
    full_native = full_native_readback(receipt)
    services, environments = collect_services(boot, anchor, contract)
    raw = (H/'gateway_state.json').read_bytes(); state = json.loads(raw); tg = state['platforms']['telegram']
    require(state['pid'] == services['gateway']['pid'] and state['start_time'] == services['gateway']['birth_ticks'] and
            state['hermes_home'] == str(H) and state['served_profiles'] == ['default','dest_telegram','telegram-bot-8812646969'] and
            state['gateway_state'] == 'running' and state['active_agents'] == 0 and state['active_work'] is None and
            state['restart_requested'] is False and state['session_store']['status'] == 'ok' and tg['state'] == 'connected' and
            tg['needs_attention'] is False and tg['writer_pid'] == state['pid'] and tg['writer_start_time'] == state['start_time'], 'gateway_routing_or_work_not_clear')
    native = transport.fresh_native(state)  # Never transport.check()/whole historic202 gate.
    require(native['quiescent'] and (H/'gateway_state.json').read_bytes() == raw, 'native_boundary_changed')
    dbs = readonly_databases()
    tester = Path('/home/jericho/.local/share/friday-telegram-bot-test')
    require(not os.path.lexists(tester/'observer-stop.json'), 'observer_stop_present')
    cooldown = load(tester/'cooldown.json') if (tester/'cooldown.json').exists() else {}
    require(cooldown.get('until', 0) <= time.time(), 'cooldown_active')
    uv = dict(x.split('=',1) for x in run(['/usr/bin/systemctl','--user','show',PUB,'--property=LoadState,MainPID,ControlPID,ControlGroup']).stdout.splitlines() if '=' in x)
    require(uv == dict(LoadState='not-found', MainPID='0', ControlPID='0', ControlGroup=''), 'publisher_unit_already_exists')
    pm = load(S/'READONLY-PM-ENVIRONMENT-BASIS.json')
    for key in ('facts', 'pyvenv_cfg'): require(sha(pm[key]['path']) == pm[key]['sha256'], 'PM_environment_pin_changed')
    require(pm['python'] == load(F/'ROOT-FUTURE-COMMANDS.json')['commands']['builder'][0] and
            str(Path(pm['python']).parent.parent) == pm['native_PM_committed_environment'] and Path(pm['python']).is_file(), 'native_PM_selected_Python_changed')
    bank_reuse = None
    if bank_check:
        runtime = load(RUNTIME); context = c.runtime_context(runtime); bankrows = c.bank_snapshot(runtime)
        template = load(F/'ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION-TEMPLATE.json'); bank = Path(template['bank_path']); critical = {}
        require(sha(BANK) == '7135caf77a9c2ae4de2c12b37a8b327cab2065e76ed87e36f675b5d95528a35c', 'retained_bank_proof_drift')
        for name, row in template['current_critical_bank_files'].items():
            path = bank/name; identity = metadata(path); require(sha(path) == row['sha256'], 'critical_bank_drift')
            critical[name] = dict(sha256=row['sha256'], metadata=identity)
        for name, digest in template['minimum_profile_source_digests'].items(): require(sha(H/'hermes-agent'/name) == receipt['files'][name]['sha256'] == digest, 'minimum_profile_source_changed')
        bank_reuse = dict(retained_full_hash=ref(BANK), runtime=ref(RUNTIME), physical_rows=len(bankrows), context_rows=len(context), critical=critical)
    mem = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))
    fs = os.statvfs(B); cpus = sorted(os.sched_getaffinity(0))
    require(mem > 8*1024**2 and fs.f_bavail*fs.f_frsize > 16*1024**3 and len(cpus) >= 2, 'insufficient_resources')
    resources = dict(memory_available_kib=mem, disk_available_bytes=fs.f_bavail*fs.f_frsize, affinity_cpus=cpus,
                     load_average=list(os.getloadavg()), pressure={k:(Path('/proc/pressure')/k).read_text() for k in ('cpu','io','memory')})
    require(collect_services(boot, anchor, contract)==(services,environments), 'service_changed_across_boundary')
    return dict(at_moscow=now(), current_anchor=ref(B/'ROOT-204-CURRENT-SERVICE-ANCHOR.json'), full_native_readback=full_native, boot_id=boot, head=head, origin_main=origin, source_origin=origin_proof, provenance_mode=mode, services=services,
                process_environment=environments, native_readonly=native, databases=dbs, cooldown=cooldown,
                publisher_unit_absent=uv, resources=resources, gateway_routing=dict(served_profiles=state['served_profiles'],
                telegram_connected=tg['state'], active_agents=state['active_agents'], active_work=state['active_work']),
                bank_reuse=bank_reuse, slot=dict(path=str(slot), dev=slot_info.st_dev,
                ino=slot_info.st_ino, Root_pid=os.getpid()), pm_basis=ref(S/'READONLY-PM-ENVIRONMENT-BASIS.json'))

def full_native_readback(receipt):
    """Physical bytes for all17891 rows; receipt counts alone are insufficient."""
    started=time.monotonic(); rows=[]
    require(len(receipt['files'])==17891, 'full17891_receipt_required')
    for name,row in sorted(receipt['files'].items()):
        require(time.monotonic()-started<=90, 'full_native_readback_budget_exhausted')
        path=H/'hermes-agent'/name
        require(Path(name).is_absolute() is False and '..' not in Path(name).parts, 'native_inventory_path_invalid')
        before=metadata(path); info=path.stat(); identity=lambda v:(v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
        digest=sha(path)
        require(before==metadata(path) and identity(info)==identity(path.stat()) and digest==row['sha256'], 'full_native_physical_drift:'+name)
        rows.append([name,digest])
    return dict(files=len(rows), physical_sha256_verified=True, inventory_digest=hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest(), elapsed_seconds=time.monotonic()-started)

def assert_old_ceased(pins, anchor):
    old=load(pins['historical_reconciliation']['old_failed204_journal']['path'])
    require(old['publisher_launch_consumed_no_retry'] is True and old['request']['sha256']==OLD_REQUEST_SHA, 'old_consumption_preserved_required')
    unit=dict(x.split('=',1) for x in run(['/usr/bin/systemctl','--user','show',OLDPUB,'--property=LoadState,ActiveState,SubState,MainPID,ControlPID,ControlGroup,InvocationID']).stdout.splitlines() if '=' in x)
    require(unit==anchor['old_publisher_unit_observation'], 'old_publisher_observation_changed')
    require(unit['MainPID']==unit['ControlPID']=='0' and unit['ControlGroup']=='' and unit['ActiveState'] in ('inactive','failed'), 'old_publisher_not_ceased')
    expected={}
    for key in ('actor_identity','publisher_client_identity','publisher_process_identity','owned_local_process_identity'):
        identity=old.get(key)
        if identity is not None: expected[key]=dict(pid=identity['pid'],birth_ticks=identity['birth_ticks'],boot_id=old['actor_identity']['boot_id'])
    require(anchor['old_processes']==expected and set(expected)>={'actor_identity','publisher_client_identity','publisher_process_identity'}, 'complete_historical_old_process_binding_required')
    for identity in anchor['old_processes'].values():
        require(set(identity)=={'pid','birth_ticks','boot_id'} and type(identity['pid']) is int and identity['pid']>0 and type(identity['birth_ticks']) is int and identity['birth_ticks']>0, 'old_process_identity_required')
        if identity['boot_id']==anchor['boot_id'] and (Path('/proc')/str(identity['pid'])).exists():
            require(birth(identity['pid'])!=identity['birth_ticks'], 'old_process_still_live')
    require(anchor['old_processes'], 'old_actor_publisher_client_identities_required')
    require(not os.path.lexists(H/'preparation'/('ordinary-source-update-v45-'+OLD_REQUEST_SHA[:16])), 'whole_old_source_transaction_consumed')

def main():
    require(__debug__ and sys.flags.isolated and sys.dont_write_bytecode and
            len(sys.argv)==4 and sys.argv[1:3] == ['--execute-once-root-reviewed-r2-204-boundary','--source-pins-sha256'], 'explicit_isolated_Root_mode_required')
    os.umask(0o077); os.environ.update(GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', HERMES_HOME=str(H))
    require(len(sys.argv[3])==64 and sha(B/'SOURCE-PINS.json') == sys.argv[3], 'source_pin_manifest_changed')
    pins = load(B/'SOURCE-PINS.json')
    for path, digest in {**pins['source_refs'], **pins['historical_refs']}.items(): require(ref(path)['sha256'] == digest, 'reviewed_source_changed:'+path)
    require(pins['schema']=='frw.root204.r2-boundary-source-pins.v1' and pins['frame']==str(F) and pins['publisher_unit']==PUB, 'exact_R2_source_domain_required')
    contract = module(B/'boundary_contract.py', 'Root204R2PureContract')
    reviewed = load(B/'ROOT-R2-BOUNDARY-SOURCE-ACCEPTANCE.json')
    require(reviewed['schema']=='frw.root204.r2-boundary-source-acceptance.v1' and reviewed['state']=='ROOT_ACCEPTED_EXACT_R2_BOUNDARY_SOURCE_ONLY' and reviewed['accepted'] is True and reviewed['execution_grant'] is False and reviewed['template_only_no_execution_grant'] is False, 'new_Root_boundary_source_acceptance_required')
    require(reviewed['source_pin_manifest']==ref(B/'SOURCE-PINS.json') and reviewed['boundary']==ref(Path(__file__)) and reviewed['caller']==ref(B/'start_core204_r2_once.py') and reviewed['frame_source_manifest']==ref(F/'SOURCE-PINS-FINAL.json'), 'exact_R2_boundary_source_acceptance_required')
    require(reviewed['independent_review_evidence'], 'independent_boundary_review_required')
    for row in reviewed['independent_review_evidence']: require(ref(row['path'])==row, 'boundary_review_evidence_changed')
    acceptance = load(F/'ROOT-204-SOURCE-ACCEPTANCE.json')
    require(acceptance['accepted'] is True and acceptance['execution_grant'] is False and acceptance['public_main_sha'] == pins['public_main_sha'], 'Root_final_source_acceptance_required')
    m = module(F/'root204_metadata.py', 'Root204binding'); c = module(APP, 'Root204unchanged_bank'); transport = module(GATE, 'Root204fresh_native_transport_only')
    anchor = load(B/'ROOT-204-CURRENT-SERVICE-ANCHOR.json')
    authority = load(B/'ROOT-204-ORIGIN-AUTHORITY.json')
    contract.validate_authority(authority, manifest=ref(B/'SOURCE-PINS.json'), boundary=ref(Path(__file__)), caller=ref(B/'start_core204_r2_once.py'), policy=ref(F/'ROOT-204-PUBLIC-ORIGIN-POLICY.json'), source_acceptance=ref(B/'ROOT-R2-BOUNDARY-SOURCE-ACCEPTANCE.json'), anchor=ref(B/'ROOT-204-CURRENT-SERVICE-ANCHOR.json'), frame=str(F))
    pins['execution_provenance_mode'] = authority['provenance_mode']
    pins['execution_commit'] = authority['execution_commit']
    pins['execution_public_main_sha'] = authority['public_main_sha']
    intent = load(E/'INTENT.json')
    require(intent['source_pin_manifest']==ref(B/'SOURCE-PINS.json') and intent['authority']==ref(B/'ROOT-204-ORIGIN-AUTHORITY.json') and intent['parent_pid']==os.getppid() and intent['parent_birth_ticks']==birth(os.getppid()), 'single_reviewed_caller_custody_required')
    op = load(F203/'ROOT-NATIVE203-LIVE-OPERATION.json')
    require(op['state'] == 'NATIVE203_PROJECT487_FRESH_PERMANENT_SERVICES_RUNNING' and op['full_selected_native_files_readback'] and op['user_db_wal_shm_verified_before_starts'] and op['publisher_closed_before_parent_custody_release'], 'accepted203_proof_required')
    slot = Path('/home/jericho/.jericho/runtime/locks/synthetic-live-acceptance.lock')
    fd = os.open(slot, os.O_RDWR | os.O_NOFOLLOW); info = os.fstat(fd)
    try:
        require((info.st_dev, info.st_ino, info.st_uid, info.st_nlink, stat.S_IMODE(info.st_mode)) == (2050,9440373,os.getuid(),1,0o600), 'shared_slot_identity_changed')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)  # Exactly once, through actor return.
        for name in ('ROOT-FRESH-REQUEST.json','ROOT-204-FRESH-READBACK.json','ROOT-204-BOUND-INPUTS.json','ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION.json','ROOT-204-FRESH-ADMISSION.json','ROOT-NATIVE204-LIVE-OPERATION.json','ROOT-NATIVE204-CUSTODY-RELEASE.json','ROOT-native204-retained-observer.stdout','ROOT-native204-retained-observer.stderr','ROOT-native204-publisher.stdout','ROOT-native204-publisher.stderr','ROOT-native204-default-check.stdout','ROOT-native204-default-check.stderr','admission-retained/READONLY-RETAINED-UNITS-INTENT.json','admission-retained/ROOT-ACTUAL-RETAINED-UNIT-OBSERVATIONS.json'):
            require(not os.path.lexists(F/name), 'once_artifact_already_exists:'+name)
        for name in ('CORE204-FRESH-ACTUAL-BOUNDARY-EVIDENCE.json','CORE204-FIRST-ACTUAL-ROOT-RETURN.json','CORE204-ROOT-ONCE-ACTOR-LAUNCHED.json','core204-actual-actor.stdout','core204-actual-actor.stderr','CORE204-BUILDER-ACTUAL-RETURN.json','CORE204-BINDER-ACTUAL-RETURN.json'):
            require(not os.path.lexists(E/name), 'Root_once_artifact_already_exists:'+name)
        evidence = boundary(m, c, transport, pins, op, anchor, contract, slot, info, bank_check=False)
        commands = load(F/'ROOT-FUTURE-COMMANDS.json')['commands']
        argv = commands['builder']; require(argv[argv.index('--layer')+1] == m.LAYER and argv.count('--layer') == 1 and
                argv[argv.index('--current-source-native-predecessor')+1] == m.PREDECESSOR['path'], 'explicit_singlelayer_canonical203_builder_required')
        builder = run(argv, timeout=90)  # Builder writes only the own fresh request; no H transaction.
        save(E/'CORE204-BUILDER-ACTUAL-RETURN.json', dict(returncode=builder.returncode, stdout=builder.stdout, stderr=builder.stderr))
        q = load(F/'ROOT-FRESH-REQUEST.json'); require(sha(F/'ROOT-FRESH-REQUEST.json')==OLD_REQUEST_SHA, 'unsalted_deterministic_request_required')
        projection = m.validate_source_request(q)
        require(projection['selected_target_count'] == 7 and projection['expected_receipt_sha256'] == AFTER, 'exact204_sevenCAS_required')
        require(not os.path.lexists(H/'preparation'/('ordinary-source-update-v45-'+sha(F/'ROOT-FRESH-REQUEST.json')[:16])), 'request_already_consumed')
        # Current readback follows builder/pin work, so metadata300s does not start during old source review.
        latest = boundary(m, c, transport, pins, op, anchor, contract, slot, info)
        require(latest['services'] == evidence['services'], 'service_changed_during_request_build')
        latest.update(source_request_projection=projection, request=ref(F/'ROOT-FRESH-REQUEST.json'), remaining_limits=LIMITS)
        save(E/'CORE204-FRESH-ACTUAL-BOUNDARY-EVIDENCE.json', latest)
        snapshot = load(F/'ROOT-204-FRESH-READBACK-TEMPLATE.json'); snapshot.pop('required_state_after_actual_Root_readback')
        # Each field derives from the successful bounded observations above or exact source join below.
        checks = dict(source_authority_verified=latest['head']==pins['execution_commit'] and latest['origin_main']==pins['execution_public_main_sha'],
            public_source_pins_verified=latest['source_origin']==m.source_origin(latest['head'], latest['origin_main'], provenance_mode=latest['provenance_mode']),
            operational_source_pins_verified=projection['project_files_after']==489,
            profile_routing_verified=latest['gateway_routing']['served_profiles']==['default','dest_telegram','telegram-bot-8812646969'],
            process_environment_verified=all(e['HERMES_HOME']==str(H) for e in latest['process_environment'].values()),
            ordinary_readonly_quiescent=latest['native_readonly']['quiescent'],
            all_three_user_db_zero_leases=len(latest['databases'])==3 and all(v['leases']==0 for v in latest['databases'].values()),
            stop_cooldown_clear=latest['cooldown'].get('until',0)<=time.time(), sole_heavy_slot_clear=latest['slot']['Root_pid']==os.getpid(),
            no_current_maintenance=latest['publisher_unit_absent']['LoadState']=='not-found',
            cancellation_clear=anchor['checks']['current_cancel_stop_cooldown_clear'] and latest['native_readonly']['quiescent'], resources_sufficient=latest['resources']['memory_available_kib']>8*1024**2,
            all_profile_owned_work_quiescent=anchor['checks']['current_all_profile_owned_work_quiescent'] and latest['native_readonly']['quiescent'] and latest['gateway_routing']['active_agents']==0 and all(v['leases']==0 for v in latest['databases'].values()),
            current_request_unconsumed=not os.path.lexists(H/'preparation'/('ordinary-source-update-v45-'+sha(F/'ROOT-FRESH-REQUEST.json')[:16])),
            old_effects_not_replayed=q['installed_layers']==203 and q['layer_names']==[m.LAYER],
            native_pm_selected_python_verified=latest['pm_basis']==ref(S/'READONLY-PM-ENVIRONMENT-BASIS.json'),
            product_services_healthy_infinite_lifetime=all(v['runtime_max']=='infinity' for v in latest['services'].values()),
            unchanged_bank_profile_evidence_reusable=latest['bank_reuse']['physical_rows']>5116 and len(latest['bank_reuse']['critical'])==4,
            known_limits_retained=latest['remaining_limits']==LIMITS)
        require(set(checks)==set(m.SNAPSHOT_TRUE_FIELDS) and all(checks.values()), 'incomplete_actual_boundary')
        snapshot.update(state='ROOT_CURRENT_READBACK_NOT_EXECUTION_GRANT', template_only_no_execution_grant=False,
            head=latest['head'], origin_main=latest['origin_main'], source_origin=latest['source_origin'], provenance_mode=latest['provenance_mode'], boot_id=latest['boot_id'], observed_at_moscow=latest['at_moscow'],
            services=latest['services'], evidence=[ref(E/'CORE204-FRESH-ACTUAL-BOUNDARY-EVIDENCE.json')], checks=checks)
        save(F/'ROOT-204-FRESH-READBACK.json', snapshot)
        pure = m.validate_join(q, acceptance, snapshot, now=time.time(), boot_id=latest['boot_id'])
        binder = run(commands['metadata_binder'], timeout=60)
        save(E/'CORE204-BINDER-ACTUAL-RETURN.json', dict(returncode=binder.returncode, stdout=binder.stdout, stderr=binder.stderr))
        qualification = load(F/'ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION-TEMPLATE.json'); qualification.pop('required_state_after_actual_Root_acceptance')
        bank = Path(qualification['bank_path']); bi = bank.lstat()
        qualification.update(state='ROOT_ACCEPTED_MINIMUM_INSTALLED_BANK_PROFILE_FOR_NATIVE204_SELECTION_NO_FORMAL_CREDIT',
            template_only_no_execution_grant=False, minimum_installed_profile_accepted=True, current_bank_profile_refreshed_at_moscow=now(),
            current_critical_bank_files=latest['bank_reuse']['critical'], bank_directory_metadata=[bi.st_dev,bi.st_ino,bi.st_uid,bi.st_gid,bi.st_mode],
            evidence=[ref(F203/'ROOT-203-MINIMUM-BANK-PROFILE-QUALIFICATION.json'), ref(BANK), ref(RUNTIME), ref(E/'CORE204-FRESH-ACTUAL-BOUNDARY-EVIDENCE.json')],
            actual_scope_and_limits='Same exact physicalbank topology/linktargets/identities+fourcriticalhashes and PDF/presentation digests; retained fullbank proof reused. Only nativeRTFreader changes; no Office/newbank/layout/user/formal credit. R104FAIL/3UNKNOWN/45unresolved/DSHA0deferred retained.')
        save(F/'ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION.json', qualification)
        admission = load(F/'ROOT-204-FRESH-ADMISSION-TEMPLATE.json'); admission.pop('required_state_after_actual_Root_review_and_qualification')
        admission.update(state='ROOT_ACCEPTED_EXACT204_SOURCE_AND_MINIMUM_INSTALLED_BANK_PROFILE_FINITE_WINDOW',
            template_only_no_execution_grant=False, accepted_at_moscow=now(), boot_id=latest['boot_id'], expected_receipt_sha256=pure['expected_receipt_sha256'],
            request=ref(F/'ROOT-FRESH-REQUEST.json'), source_acceptance=ref(F/'ROOT-204-SOURCE-ACCEPTANCE.json'),
            bound_inputs=ref(F/'ROOT-204-BOUND-INPUTS.json'), minimum_installed_bank_profile_qualification=ref(F/'ROOT-204-MINIMUM-BANK-PROFILE-QUALIFICATION.json'))
        save(F/'ROOT-204-FRESH-ADMISSION.json', admission)
        final = boundary(m, c, transport, pins, op, anchor, contract, slot, info)
        require(final['services']==latest['services'] and final['process_environment']==latest['process_environment'], 'service_changed_before_actor')
        require(ref(B/'ROOT-204-CURRENT-SERVICE-ANCHOR.json')==authority['current_service_anchor'] and ref(B/'ROOT-204-ORIGIN-AUTHORITY.json')==intent['authority'], 'Root_authority_changed_before_actor')
        require(not os.path.lexists(H/'preparation'/('ordinary-source-update-v45-'+OLD_REQUEST_SHA[:16])), 'whole_transaction_consumed_before_actor')
        require(m.load_actor_binding(F)==pure, 'last_exact_binding_changed')
        contract.validate_anchor(anchor, current_time=time.time(), boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip(), historical=pins['historical_reconciliation'], expected_request_sha256=OLD_REQUEST_SHA, frame=str(F), publisher=PUB)
        result = launch_once(commands['once_actor'], fd, latest['boot_id'])
        result.update(state='ROOT_ONCE204_ACTOR_RETURN_RECONCILE_ACTUAL_RESULT', at_moscow=now(),
                      journal=ref(F/'ROOT-NATIVE204-LIVE-OPERATION.json') if (F/'ROOT-NATIVE204-LIVE-OPERATION.json').exists() else None)
        save(E/'CORE204-FIRST-ACTUAL-ROOT-RETURN.json', result); print(json.dumps(result))
        require(not result['deferred_parent_signals'], 'parent_stop_deferred_until_same_actor_return')
    finally:
        # Never LOCK_UN: child's inherited description retains custody if parent dies.
        os.close(fd)

if __name__ == '__main__': main()
